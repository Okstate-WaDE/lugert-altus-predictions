"""Prediction and residual intervals from an offline-trained Altus model bundle."""

from datetime import date, timedelta
from importlib.metadata import version
from pathlib import Path
import platform

import joblib
import numpy as np
import pandas as pd

from models.feature_engineering import build_features


def validate_bundle(bundle, model_version):
    if not isinstance(bundle, dict) or bundle.get("schema_version") != 1:
        raise ValueError("Unsupported model bundle. Re-export with tools/export_model.py.")
    if bundle.get("model_version") != model_version:
        raise ValueError("The model bundle does not match this function's MODEL_VERSION.")
    if bundle.get("prediction_kind") != "log_regressor":
        raise ValueError("Unsupported prediction_kind; expected log_regressor.")
    if bundle.get("best_model_name") != "RF_DailyNext30":
        raise ValueError("This deployment supports the scripts' selected RF_DailyNext30 model.")
    required = ("predictor", "imputer", "feature_columns", "intervals", "feature_config")
    missing = [key for key in required if key not in bundle]
    if missing:
        raise ValueError(f"Model bundle missing fields: {missing}")
    columns = bundle["feature_columns"]
    if not columns or len(columns) != len(set(columns)):
        raise ValueError("feature_columns must contain distinct feature names.")
    trained_versions = bundle.get("runtime_versions", {})
    for package in ("numpy", "pandas", "scipy", "scikit-learn", "joblib"):
        current = version(package)
        trained = trained_versions.get(package)
        if trained != current:
            raise ValueError(
                f"Bundle/runtime mismatch for {package}: trained={trained}, runtime={current}. "
                "Export the model using the same Docker image used for Lambda."
            )
    trained_python = trained_versions.get("python", "")
    if trained_python.split(".")[:2] != platform.python_version().split(".")[:2]:
        raise ValueError("Python major/minor differs. Re-export in the Lambda Docker image.")


def load_bundle(path, model_version):
    # joblib uses pickle: only load artifacts created by your trusted exporter.
    bundle = joblib.load(Path(path))
    validate_bundle(bundle, model_version)
    return bundle


def predict(bundle, data_path, rain_path, soil_path, as_of=None):
    """Predict the inflow sum for the 30 days AFTER the requested origin day."""
    if as_of is not None:
        if not isinstance(as_of, str):
            raise ValueError("as_of must be a YYYY-MM-DD string.")
        try:
            parsed = date.fromisoformat(as_of)
        except ValueError as as_error:
            raise ValueError("as_of must be a YYYY-MM-DD string.") from as_error
        if parsed.isoformat() != as_of:
            raise ValueError("as_of must be a YYYY-MM-DD string.")

    features = build_features(
        data_path, rain_path, soil_path, bundle["model_version"],
        as_of=as_of, feature_config=bundle["feature_config"],
    )
    if features.empty:
        raise ValueError("No feature rows available for prediction.")
    origin = pd.Timestamp(as_of) if as_of else features["date_day"].max()
    row = features.loc[features["date_day"] == origin]
    if len(row) != 1:
        raise ValueError(f"Expected exactly one inflow row for {origin.date()}.")
    columns = bundle["feature_columns"]
    missing = sorted(set(columns) - set(row.columns))
    if missing:
        raise ValueError(f"Inference cannot construct trained features: {missing}")
    x = row[columns].astype(float)
    if np.isinf(x.to_numpy()).any():
        raise ValueError("Input features contain infinite values.")
    imputed_features = x.columns[x.isna().any()].tolist()
    transformed = bundle["imputer"].transform(x)
    predicted = float(np.expm1(bundle["predictor"].predict(transformed)[0]))
    month = int(origin.month)
    intervals = bundle["intervals"]
    result = {
        "model_version": bundle["model_version"],
        "model_name": bundle["best_model_name"],
        "as_of": origin.date().isoformat(),
        "forecast_start": (origin.date() + timedelta(days=1)).isoformat(),
        "forecast_end": (origin.date() + timedelta(days=30)).isoformat(),
        "horizon_days": 30,
        "y_pred_next30": predicted,
        "imputed_features": imputed_features,
        "production_training": bundle.get("production_training", {}),
        "interval_calibration": bundle.get("interval_calibration", {}),
    }
    for level in (50, 90):
        for side in ("lo", "hi"):
            offset = intervals[f"q{side}{level}_map"].get(
                month, intervals[f"g{side}{level}"]
            )
            result[f"y_{side}{level}"] = predicted + float(offset)
    # Preserve original-script intervals, including negative lower bounds.
    numeric = [value for value in result.values() if isinstance(value, (int, float))]
    if not np.isfinite(numeric).all():
        raise ValueError("The model returned non-finite predictions or intervals.")
    return result
