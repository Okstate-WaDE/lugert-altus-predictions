"""S3-backed prediction-only handler shared by the v6 and v9 Lambda functions."""

from datetime import datetime, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import tempfile
import time
import uuid

from inference import load_bundle, predict


LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)
INPUT_FILES = (
    "ALTU_ALL.csv",
    "ERA5Land_daily_area_weighted_subbasin_rainfall.csv",
    "ERA5Land_daily_area_weighted_subbasin_soil_moisture.csv",
)
_MODEL_CACHE = None
ARTIFACT_ROOT = Path(__file__).resolve().parent / "artifacts"


def _get_image_model(model_version):
    global _MODEL_CACHE
    path = ARTIFACT_ROOT / model_version / "model.joblib"
    identity = ("image", str(path), model_version)
    if _MODEL_CACHE is not None and _MODEL_CACHE[0] == identity:
        return _MODEL_CACHE[1], _MODEL_CACHE[2]
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    metadata = json.loads(path.with_name("metadata.json").read_text(encoding="utf-8"))
    if digest != metadata["artifact_sha256"]:
        raise ValueError("Packaged model does not match its metadata checksum")
    bundle = load_bundle(path, model_version)
    _MODEL_CACHE = (identity, bundle, digest)
    return bundle, digest


def _s3_client():
    import boto3
    from botocore.config import Config

    return boto3.client(
        "s3", config=Config(connect_timeout=10, read_timeout=60,
                            retries={"max_attempts": 3, "mode": "standard"})
    )


def _download(s3, bucket, key, destination):
    from boto3.s3.transfer import TransferConfig

    s3.download_file(bucket, key, str(destination), Config=TransferConfig(use_threads=False))


def _required_env(name):
    value = os.environ.get(name, "").strip()
    if not value:
        raise ValueError(f"Missing required environment variable: {name}")
    return value


def _prefix(value):
    if not isinstance(value, str) or not value.strip("/"):
        raise ValueError("S3 prefixes must be nonempty strings.")
    if value.startswith("/") or "\\" in value or any(p in (".", "..", "") for p in value.rstrip("/").split("/")):
        raise ValueError("Use an S3 prefix such as inputs/ or inputs/2026-09-24/.")
    return value.rstrip("/") + "/"


def _get_model(s3, bucket, key, model_version):
    global _MODEL_CACHE
    metadata = s3.head_object(Bucket=bucket, Key=key)
    identity = (bucket, key, metadata["ETag"], metadata.get("VersionId"), model_version)
    if _MODEL_CACHE is not None and _MODEL_CACHE[0] == identity:
        return _MODEL_CACHE[1], metadata["ETag"]
    with tempfile.TemporaryDirectory(prefix="altus-model-") as work:
        path = Path(work) / "model.joblib"
        _download(s3, bucket, key, path)
        # Detect replacement between HEAD and download; do not cache the wrong artifact.
        after = s3.head_object(Bucket=bucket, Key=key)
        if after["ETag"] != metadata["ETag"] or after.get("VersionId") != metadata.get("VersionId"):
            raise RuntimeError("Model changed while downloading. Retry with a stable model key.")
        bundle = load_bundle(path, model_version)
    _MODEL_CACHE = (identity, bundle)
    return bundle, metadata["ETag"]


def lambda_handler(event, context):
    """Event: {} or {"as_of": "YYYY-MM-DD", "input_prefix": "inputs/snapshot/"}."""
    started = time.monotonic()
    if not isinstance(event, dict):
        raise ValueError("Pass a JSON object, for example {}.")
    unknown = sorted(set(event) - {"as_of", "input_prefix"})
    if unknown:
        raise ValueError(f"Unsupported event fields: {unknown}")
    model_version = _required_env("MODEL_VERSION")
    if model_version not in ("v6", "v9"):
        raise ValueError("MODEL_VERSION must be v6 or v9.")
    input_bucket = _required_env("INPUT_BUCKET")
    output_bucket = _required_env("OUTPUT_BUCKET")
    model_source = os.environ.get("MODEL_SOURCE", "s3")
    if model_source not in ("s3", "image"):
        raise ValueError("MODEL_SOURCE must be s3 or image")
    model_bucket = _required_env("MODEL_BUCKET") if model_source == "s3" else None
    model_key = _required_env("MODEL_KEY") if model_source == "s3" else None
    configured_input_prefix = _prefix(os.environ.get("INPUT_PREFIX", "inputs/"))
    s3 = None
    manifest = {}
    manifest_key = os.environ.get("DATA_MANIFEST_KEY")
    if manifest_key:
        s3 = _s3_client()
        manifest = json.loads(s3.get_object(Bucket=input_bucket, Key=manifest_key)["Body"].read())
        if model_source == "s3":
            model_key = manifest.get("model_keys", {}).get(model_version, model_key)
            if not model_key.startswith(f"models/{model_version}/"):
                raise ValueError("Published model key is outside this version's model prefix.")
    input_prefix = _prefix(event.get("input_prefix", manifest.get("input_prefix", configured_input_prefix)))
    if not input_prefix.startswith(configured_input_prefix):
        raise ValueError("input_prefix must be within the configured INPUT_PREFIX.")
    output_prefix = _prefix(os.environ.get("OUTPUT_PREFIX", "outputs/"))
    if s3 is None:
        s3 = _s3_client()
    if model_source == "image":
        bundle, model_digest = _get_image_model(model_version)
        model_etag = None
    else:
        bundle, model_etag = _get_model(s3, model_bucket, model_key, model_version)
        model_digest = None
    request_id = getattr(context, "aws_request_id", None) or uuid.uuid4().hex
    # Never use event values as local file paths.
    with tempfile.TemporaryDirectory(prefix="altus-predict-") as work:
        workdir = Path(work)
        input_manifest = []
        for filename in INPUT_FILES:
            path = workdir / filename
            key = input_prefix + filename
            _download(s3, input_bucket, key, path)
            input_manifest.append({
                "s3_uri": f"s3://{input_bucket}/{key}",
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            })
        default_date = manifest.get("as_of") if "input_prefix" not in event else None
        prediction = predict(bundle, *(workdir / name for name in INPUT_FILES), as_of=event.get("as_of", default_date))

    result_key = f"{output_prefix}{model_version}/{request_id}/prediction.json"
    result = {
        "status": "ok",
        "request_id": request_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "prediction": prediction,
        "model_source": model_source,
        "model_s3_uri": f"s3://{model_bucket}/{model_key}" if model_source == "s3" else None,
        "model_sha256": model_digest,
        "model_etag": model_etag,
        "inputs": input_manifest,
        "result_s3_uri": f"s3://{output_bucket}/{result_key}",
        "duration_seconds": round(time.monotonic() - started, 3),
    }
    s3.put_object(
        Bucket=output_bucket, Key=result_key,
        Body=json.dumps(result, indent=2, allow_nan=False).encode("utf-8"),
        ContentType="application/json",
    )
    LOGGER.info("Prediction complete version=%s as_of=%s result=%s", model_version,
                prediction["as_of"], result["result_s3_uri"])
    return result
