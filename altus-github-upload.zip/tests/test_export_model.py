"""Production refits must consume all current labeled history, not fixed splits."""

from pathlib import Path
import sys
import tempfile
import unittest

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools.export_model import refit_production_model, verify_serialization


def fixture(version="v6", start="2023-12-01", end="2025-03-01"):
    dates = pd.date_range(start, end, freq="D")
    values = np.arange(len(dates), dtype=float) + 1
    daily = pd.DataFrame({
        "date_day": dates, "year": dates.year, "observed_feature": values,
        "inflow_next30": pd.Series(values).shift(-30).rolling(30, min_periods=30).sum(),
    })
    daily["inflow_next30_log"] = np.log1p(daily["inflow_next30"])
    labeled = daily.dropna().reset_index(drop=True)
    benchmark = labeled.loc[labeled["year"] <= 2023]
    if benchmark.empty:
        benchmark = labeled.head(10)
    imputer = SimpleImputer(strategy="mean")
    X = imputer.fit_transform(benchmark[["observed_feature"]])
    rf = RandomForestRegressor(n_estimators=3, max_depth=2, random_state=16, bootstrap=False, n_jobs=1)
    rf.fit(X, benchmark["inflow_next30_log"])
    namespace = {"daily": daily, "daily_model_df": labeled, "rf_d": rf, "imp_d": imputer}
    if version == "v9":
        namespace["TRAIN_START"] = 1995
    bundle = {
        "model_version": version,
        "feature_columns": ["observed_feature"],
        "feature_config": {},
        "predictor": rf,
        "imputer": imputer,
        "intervals": {"glo90": -3.0, "ghi90": 4.0},
    }
    return namespace, bundle


class ProductionRefitTests(unittest.TestCase):
    def test_refits_every_labeled_row_including_old_validation_and_test_years(self):
        namespace, bundle = fixture()
        benchmark_imputer_mean = namespace["imp_d"].statistics_.copy()
        original_rf = namespace["rf_d"]
        rows = refit_production_model(bundle, namespace)

        self.assertGreater(int(rows["year"].max()), 2023)
        self.assertEqual(len(rows), len(namespace["daily_model_df"]))
        self.assertEqual(bundle["predictor"].estimators_[0].tree_.n_node_samples[0], len(rows))
        self.assertAlmostEqual(bundle["imputer"].statistics_[0], rows["observed_feature"].mean())
        self.assertFalse(np.allclose(benchmark_imputer_mean, bundle["imputer"].statistics_))
        self.assertIsNot(bundle["predictor"], original_rf)
        self.assertEqual(bundle["predictor"].get_params(), original_rf.get_params())
        np.testing.assert_array_equal(namespace["imp_d"].statistics_, benchmark_imputer_mean)

    def test_excludes_last_thirty_unknown_targets_and_marks_transferred_intervals(self):
        namespace, bundle = fixture()
        saved_intervals = dict(bundle["intervals"])
        rows = refit_production_model(bundle, namespace)
        expected_last_origin = namespace["daily"]["date_day"].max() - pd.Timedelta(days=30)

        self.assertEqual(rows["date_day"].max(), expected_last_origin)
        self.assertTrue(rows["inflow_next30"].notna().all())
        self.assertEqual(bundle["production_training"]["excluded_recent_unlabeled_rows"], 30)
        self.assertEqual(bundle["production_training"]["target_through"], "2025-03-01")
        self.assertEqual(bundle["intervals"], saved_intervals)
        self.assertTrue(bundle["interval_calibration"]["approximate_for_production"])

    def test_v9_keeps_pre_1995_rows_as_history_only(self):
        namespace, bundle = fixture("v9", "1994-11-01", "1995-04-01")
        rows = refit_production_model(bundle, namespace)
        self.assertEqual(rows["date_day"].min(), pd.Timestamp("1995-01-01"))
        self.assertTrue((rows["year"] >= 1995).all())
        self.assertEqual(bundle["production_training"]["rows"], len(rows))

    def test_reloaded_production_predictions_match(self):
        namespace, bundle = fixture()
        rows = refit_production_model(bundle, namespace)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model.joblib"
            joblib.dump(bundle, path)
            result = verify_serialization(bundle, rows, path)
        self.assertTrue(result["prediction_parity"])
        self.assertEqual(result["rows"], len(rows))


if __name__ == "__main__":
    unittest.main()
