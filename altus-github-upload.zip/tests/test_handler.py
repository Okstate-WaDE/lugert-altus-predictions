"""Prediction, serialization, and S3 orchestration tests; no AWS access or training."""

from copy import deepcopy
import hashlib
from importlib import metadata
import io
import json
import os
from pathlib import Path
import platform
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import joblib
import numpy as np
import pandas as pd

PACKAGE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_DIR))

import inference
import lambda_function as handler


class IdentityImputer:
    def transform(self, values):
        return np.nan_to_num(np.asarray(values, dtype=float))


class FixedPredictor:
    def __init__(self, prediction=12.5):
        self.prediction = prediction

    def predict(self, values):
        return np.full(len(values), np.log1p(self.prediction))


def bundle_for(model_version="v6", prediction=12.5):
    versions = {
        package: metadata.version(package)
        for package in ("numpy", "pandas", "scipy", "scikit-learn", "joblib")
    }
    versions["python"] = platform.python_version()
    return {
        "schema_version": 1,
        "model_version": model_version,
        "prediction_kind": "log_regressor",
        "best_model_name": "RF_DailyNext30",
        "predictor": FixedPredictor(prediction),
        "imputer": IdentityImputer(),
        "feature_columns": ["basin_flow", "rain_7d"],
        "feature_config": {},
        "runtime_versions": versions,
        "intervals": {
            "qlo50_map": {1: -1.0}, "qhi50_map": {1: 2.0},
            "glo50": -3.0, "ghi50": 4.0,
            "qlo90_map": {}, "qhi90_map": {},
            "glo90": -20.0, "ghi90": 8.0,
        },
    }


def bundle_bytes(bundle):
    output = io.BytesIO()
    joblib.dump(bundle, output)
    return output.getvalue()


class FakeS3:
    def __init__(self):
        self.objects = {}
        self.metadata = {}
        self.downloads = []
        self.writes = []
        self.after_download = None
        self.write_error = None

    def store(self, bucket, key, content, etag=None, version_id="1"):
        self.objects[bucket, key] = content
        self.metadata[bucket, key] = {
            "ETag": etag or hashlib.sha256(content).hexdigest(),
            "VersionId": version_id,
        }

    def head_object(self, Bucket, Key):
        return dict(self.metadata[Bucket, Key])

    def get_object(self, Bucket, Key):
        return {"Body": io.BytesIO(self.objects[Bucket, Key])}

    def download_file(self, bucket, key, destination):
        self.downloads.append((bucket, key))
        if (bucket, key) not in self.objects:
            raise FileNotFoundError(f"s3://{bucket}/{key}")
        Path(destination).write_bytes(self.objects[bucket, key])
        if self.after_download:
            self.after_download(bucket, key)

    def put_object(self, **request):
        if self.write_error:
            raise self.write_error
        self.writes.append(request)
        return {"ETag": "written"}


class HandlerTests(unittest.TestCase):
    def setUp(self):
        handler._MODEL_CACHE = None
        self.addCleanup(setattr, handler, "_MODEL_CACHE", None)
        self.fake = FakeS3()
        self.context = SimpleNamespace(aws_request_id="request-123")
        self.env = {
            "MODEL_VERSION": "v6", "MODEL_BUCKET": "data-bucket",
            "MODEL_KEY": "models/v6/model.joblib", "INPUT_BUCKET": "data-bucket",
            "INPUT_PREFIX": "inputs/", "OUTPUT_BUCKET": "data-bucket",
            "OUTPUT_PREFIX": "outputs/",
        }
        for patcher in (
            patch.dict(os.environ, self.env),
            patch.object(handler, "_s3_client", return_value=self.fake),
            patch.object(handler, "_download", side_effect=lambda s3, b, k, p: s3.download_file(b, k, p)),
            patch("runpy.run_path", side_effect=AssertionError("Training must not run during prediction")),
        ):
            patcher.start()
            self.addCleanup(patcher.stop)
        self.features = pd.DataFrame({
            "date_day": pd.to_datetime(["2025-01-01", "2025-01-02"]),
            "basin_flow": [1.0, 2.0], "rain_7d": [0.5, np.nan],
        })
        feature_patcher = patch.object(inference, "build_features", side_effect=self.build_features)
        self.feature_mock = feature_patcher.start()
        self.addCleanup(feature_patcher.stop)
        self.install_inputs()
        self.install_model()

    def install_inputs(self, prefix="inputs/"):
        for name in handler.INPUT_FILES:
            self.fake.store("data-bucket", prefix + name, b"date,value\n2025-01-02,2\n")

    def install_model(self, model_version="v6", prediction=12.5, **metadata_options):
        key = f"models/{model_version}/model.joblib"
        self.fake.store("data-bucket", key, bundle_bytes(bundle_for(model_version, prediction)), **metadata_options)
        os.environ.update(MODEL_VERSION=model_version, MODEL_KEY=key)

    def build_features(self, *args, **kwargs):
        for path in args[:3]:
            self.assertEqual(Path(path).read_bytes(), b"date,value\n2025-01-02,2\n")
        self.assertEqual(args[3], os.environ["MODEL_VERSION"])
        return self.features.copy()

    def test_both_versions_load_serialized_model_predict_and_write_result(self):
        for model_version in ("v6", "v9"):
            with self.subTest(model_version=model_version):
                self.install_model(model_version)
                result = handler.lambda_handler({}, self.context)
                self.assertEqual(result["status"], "ok")
                self.assertEqual(result["prediction"]["model_version"], model_version)
                self.assertAlmostEqual(result["prediction"]["y_pred_next30"], 12.5)
                self.assertEqual(result["prediction"]["as_of"], "2025-01-02")
                written = self.fake.writes[-1]
                self.assertEqual(written["Bucket"], "data-bucket")
                self.assertEqual(written["Key"], f"outputs/{model_version}/request-123/prediction.json")
                self.assertEqual(written["ContentType"], "application/json")
                self.assertEqual(json.loads(written["Body"]), result)
                self.assertEqual(len(result["inputs"]), 3)
                self.assertTrue(all(len(item["sha256"]) == 64 for item in result["inputs"]))

    def test_published_manifest_selects_matching_snapshot_model_and_available_date(self):
        prefix = "inputs/runs/snapshot-1/"
        key = "models/v6/runs/snapshot-1/model.joblib"
        self.install_inputs(prefix)
        self.fake.store("data-bucket", key, bundle_bytes(bundle_for("v6", prediction=19.)))
        self.fake.store("data-bucket", "inputs/current.json", json.dumps({
            "input_prefix": prefix, "model_keys": {"v6": key}, "as_of": "2025-01-01"
        }).encode())
        with patch.dict(os.environ, {"DATA_MANIFEST_KEY": "inputs/current.json"}):
            result = handler.lambda_handler({}, self.context)
        self.assertAlmostEqual(result["prediction"]["y_pred_next30"], 19.)
        self.assertEqual(result["prediction"]["as_of"], "2025-01-01")
        self.assertEqual(result["model_s3_uri"], "s3://data-bucket/" + key)
        self.assertTrue(all(prefix in row["s3_uri"] for row in result["inputs"]))
        self.assertNotIn("models.model_v6", sys.modules)
        self.assertNotIn("models.model_v9", sys.modules)

    def test_warm_cache_reuses_bundle_and_etag_replacement_invalidates_it(self):
        handler.lambda_handler({}, self.context)
        handler.lambda_handler({}, self.context)
        model_key = ("data-bucket", "models/v6/model.joblib")
        self.assertEqual(self.fake.downloads.count(model_key), 1)
        self.install_model(prediction=30.0)
        result = handler.lambda_handler({}, self.context)
        self.assertEqual(self.fake.downloads.count(model_key), 2)
        self.assertAlmostEqual(result["prediction"]["y_pred_next30"], 30.0)

    def test_version_id_change_invalidates_cache_even_when_etag_matches(self):
        self.install_model(etag="unchanged", version_id="first")
        handler.lambda_handler({}, self.context)
        self.install_model(etag="unchanged", version_id="second")
        handler.lambda_handler({}, self.context)
        self.assertEqual(self.fake.downloads.count(("data-bucket", "models/v6/model.joblib")), 2)

    def test_model_replacement_during_download_fails_without_caching_or_output(self):
        def replace_etag(bucket, key):
            self.fake.metadata[bucket, key]["ETag"] = "replacement"
        self.fake.after_download = replace_etag
        with self.assertRaisesRegex(RuntimeError, "changed while downloading"):
            handler.lambda_handler({}, self.context)
        self.assertIsNone(handler._MODEL_CACHE)
        self.assertEqual(self.fake.writes, [])

    def test_nested_input_prefix_and_explicit_date(self):
        self.install_inputs("inputs/snapshot/")
        result = handler.lambda_handler({"input_prefix": "inputs/snapshot", "as_of": "2025-01-01"}, self.context)
        self.assertEqual(result["prediction"]["as_of"], "2025-01-01")
        self.assertTrue(all("/inputs/snapshot/" in item["s3_uri"] for item in result["inputs"]))

    def test_prefix_escape_and_traversal_fail_before_any_s3_access(self):
        for prefix in ("../outside/", "inputs-other/", "outputs/", "inputs/../data/", "inputs//data/", "/inputs/", ""):
            with self.subTest(prefix=prefix), self.assertRaises(ValueError):
                handler.lambda_handler({"input_prefix": prefix}, self.context)
        os.environ["INPUT_PREFIX"] = "inputs/release/"
        with self.assertRaisesRegex(ValueError, "within the configured"):
            handler.lambda_handler({"input_prefix": "inputs/other/"}, self.context)
        self.assertEqual(self.fake.downloads, [])
        self.assertEqual(self.fake.writes, [])

    def test_unsupported_event_and_missing_config_fail(self):
        for event in (None, [], {"model_version": "v9"}, {"input_bucket": "other"}):
            with self.subTest(event=event), self.assertRaises(ValueError):
                handler.lambda_handler(event, self.context)
        del os.environ["MODEL_BUCKET"]
        with self.assertRaisesRegex(ValueError, "MODEL_BUCKET"):
            handler.lambda_handler({}, self.context)
        self.assertEqual(self.fake.writes, [])

    def test_missing_input_fails_without_a_success_output(self):
        del self.fake.objects["data-bucket", "inputs/ALTU_ALL.csv"]
        with self.assertRaises(FileNotFoundError):
            handler.lambda_handler({}, self.context)
        self.feature_mock.assert_not_called()
        self.assertEqual(self.fake.writes, [])

    def test_prediction_and_output_failures_propagate(self):
        with patch.object(handler, "predict", side_effect=ValueError("bad input")):
            with self.assertRaisesRegex(ValueError, "bad input"):
                handler.lambda_handler({}, self.context)
        self.assertEqual(self.fake.writes, [])
        self.fake.write_error = PermissionError("S3 output denied")
        with self.assertRaisesRegex(PermissionError, "S3 output denied"):
            handler.lambda_handler({}, self.context)
        self.assertEqual(self.fake.writes, [])


class InferenceTests(unittest.TestCase):
    def test_runtime_or_model_version_mismatch_is_rejected(self):
        bundle = bundle_for()
        inference.validate_bundle(bundle, "v6")
        with self.assertRaisesRegex(ValueError, "MODEL_VERSION"):
            inference.validate_bundle(bundle, "v9")
        for package in ("numpy", "pandas", "scipy", "scikit-learn", "joblib", "python"):
            invalid = deepcopy(bundle)
            invalid["runtime_versions"][package] = "0.0.0"
            with self.subTest(package=package), self.assertRaises(ValueError):
                inference.validate_bundle(invalid, "v6")

    def test_month_specific_and_global_intervals_match_original_output_scale(self):
        frame = pd.DataFrame({"date_day": pd.to_datetime(["2025-01-02"]), "basin_flow": [1.0], "rain_7d": [np.nan]})
        with patch.object(inference, "build_features", return_value=frame):
            prediction = inference.predict(bundle_for(), "data", "rain", "soil")
        self.assertAlmostEqual(prediction["y_pred_next30"], 12.5)
        self.assertAlmostEqual(prediction["y_lo50"], 11.5)
        self.assertAlmostEqual(prediction["y_hi50"], 14.5)
        self.assertAlmostEqual(prediction["y_lo90"], -7.5)
        self.assertAlmostEqual(prediction["y_hi90"], 20.5)
        self.assertEqual(prediction["forecast_start"], "2025-01-03")
        self.assertEqual(prediction["forecast_end"], "2025-02-01")
        self.assertEqual(prediction["imputed_features"], ["rain_7d"])

    def test_invalid_date_and_nonfinite_prediction_fail(self):
        for as_of in ("20250102", "2025-W01-1", "2025-02-30", 123):
            with self.subTest(as_of=as_of), self.assertRaisesRegex(ValueError, "YYYY-MM-DD"):
                inference.predict(bundle_for(), "data", "rain", "soil", as_of=as_of)
        frame = pd.DataFrame({"date_day": pd.to_datetime(["2025-01-02"]), "basin_flow": [1.0], "rain_7d": [1.0]})
        with patch.object(inference, "build_features", return_value=frame):
            with self.assertRaisesRegex(ValueError, "non-finite"):
                inference.predict(bundle_for(prediction=np.nan), "data", "rain", "soil")


if __name__ == "__main__":
    unittest.main()
