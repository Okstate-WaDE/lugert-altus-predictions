import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import lambda_function as handler
from test_handler import bundle_for, bundle_bytes, FakeS3


class ImageModelsTests(unittest.TestCase):
    def tearDown(self):
        handler._MODEL_CACHE = None

    def test_checksum_and_cache(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / 'v6').mkdir()
            data = bundle_bytes(bundle_for())
            (root / 'v6/model.joblib').write_bytes(data)
            (root / 'v6/metadata.json').write_text(json.dumps({'artifact_sha256': hashlib.sha256(data).hexdigest()}))
            with patch.object(handler, 'ARTIFACT_ROOT', root):
                first, digest = handler._get_image_model('v6')
                second, _ = handler._get_image_model('v6')
                self.assertIs(first, second)
                handler._MODEL_CACHE = None
                (root / 'v6/model.joblib').write_bytes(b'bad model')
                with self.assertRaisesRegex(ValueError, 'checksum'):
                    handler._get_image_model('v6')

    def test_image_ignores_manifest_model_key_and_needs_no_s3_model_permissions(self):
        s3 = FakeS3()
        s3.store('bucket', 'inputs/current.json', json.dumps({'as_of': '2026-08-31', 'model_keys': {'v6': 'ignored'}}).encode())
        for filename in handler.INPUT_FILES:
            s3.store('bucket', 'inputs/' + filename, b'test input')
        def download(client, bucket, key, path):
            path.write_bytes(client.objects[bucket, key])
        with patch.dict(os.environ, {'MODEL_SOURCE': 'image', 'MODEL_VERSION': 'v6', 'INPUT_BUCKET': 'bucket', 'OUTPUT_BUCKET': 'bucket', 'DATA_MANIFEST_KEY': 'inputs/current.json'}, clear=True), \
             patch.object(handler, '_s3_client', return_value=s3), \
             patch.object(handler, '_download', side_effect=download), \
             patch.object(handler, '_get_image_model', return_value=({}, 'digest')) as local, \
             patch.object(handler, '_get_model') as remote, \
             patch.object(handler, 'predict', return_value={'as_of': '2026-08-31'}) as predict:
            result = handler.lambda_handler({}, None)
        remote.assert_not_called()
        local.assert_called_once_with('v6')
        self.assertEqual(predict.call_args.kwargs['as_of'], '2026-08-31')
        self.assertIsNone(result['model_s3_uri'])
        self.assertEqual(result['model_sha256'], 'digest')
