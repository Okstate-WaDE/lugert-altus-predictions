"""Feature parity is checked against the preserved training sources, without fitting."""

import ast
from contextlib import redirect_stdout
import io
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from models.feature_engineering import (  # noqa: E402
    CANONICAL_SUBBASINS, COL_INFLOW, COL_RAIN_DAM, COL_RAIN_BSN, build_features,
)


class FeatureEngineeringTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.days = pd.date_range("2022-01-01", periods=440, freq="D")
        n = np.arange(len(self.days), dtype=float)
        self.inflow = pd.DataFrame({
            "year": self.days.year, "month": self.days.month, "day": self.days.day,
            COL_INFLOW: 3.0 + 0.05 * n + 8.0 * np.square(np.sin(n / 5.0)),
            COL_RAIN_DAM: np.where(n % 7 == 0, 0.8, 0.0),
            COL_RAIN_BSN: np.where(n % 11 == 0, 1.1, 0.0),
        })
        self.inflow.loc[90, COL_INFLOW] = np.nan
        rain, soil = [], []
        for index, basin in enumerate(CANONICAL_SUBBASINS):
            # Include a nearby legacy area and a duplicate observation to test
            # canonical mapping and the original per-day averaging behavior.
            area = basin["representative_area_m2"] * (1 + index * 0.001)
            for day_index, day in enumerate(self.days):
                rain.append({"date": day.strftime("%Y-%m-%d"), "area_m2_used": area,
                             "rain_mm_aw": float((day_index * (index + 1)) % 17)})
                soil.append({"date": day.strftime("%Y-%m-%d"), "area_m2_used": area,
                             "sm_aw": 0.1 + index * 0.08 + np.sin(day_index / 12) * 0.03})
        rain.append(dict(rain[100], rain_mm_aw=10.0))
        self.rain = pd.DataFrame(rain)
        self.soil = pd.DataFrame(soil)
        self.rain.loc[111, "rain_mm_aw"] = np.nan
        self.soil.loc[222, "sm_aw"] = np.nan
        self.paths = [self.directory / name for name in ("inflow.csv", "rain.csv", "soil.csv")]
        self.write_inputs()

    def write_inputs(self):
        for frame, path in zip((self.inflow, self.rain, self.soil), self.paths):
            frame.to_csv(path, index=False)

    def original_features(self, version):
        """Execute original feature statements only, never imports/training/plots."""
        source_path = PROJECT_ROOT / "models" / f"model_{version}.py"
        source = source_path.read_text(encoding="utf-8-sig")
        tree = ast.parse(source)
        wanted_constants = {
            "CANONICAL_SUBBASINS", "SUBBASIN_AREA_TOLERANCE_PCT",
            "HIGH_QIN30_QUANTILE", "RAINFALL_ROLLING_WINDOWS",
        }
        nodes = []
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name == "build_area_subbasin_features":
                nodes.append(node)
            elif isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id in wanted_constants for target in node.targets
            ):
                nodes.append(node)
        namespace = {
            "np": np, "pd": pd, "Path": Path, "OUT_DIR": self.directory,
            "COL_INFLOW": COL_INFLOW, "COL_RAIN_DAM": COL_RAIN_DAM,
            "COL_RAIN_BSN": COL_RAIN_BSN,
        }
        exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source_path), "exec"), namespace)
        daily = pd.read_csv(self.paths[0])
        daily["date_day"] = self.days
        daily["split"] = "train"
        daily["rainfall_altu_combined"] = daily[COL_RAIN_DAM] + daily[COL_RAIN_BSN]
        with redirect_stdout(io.StringIO()):
            sub_features, sub_columns, _ = namespace["build_area_subbasin_features"](
                self.paths[1], self.paths[2]
            )
            namespace["daily"] = daily.merge(sub_features, on="date_day", how="left")
            start = source.index("# 3. Base lag feature")
            end = source.index("# 4. Target:", start)
            exec(compile(source[start:end], str(source_path), "exec"), namespace)
        return namespace, sub_columns

    def test_features_match_original_sources(self):
        for version in ("v6", "v9"):
            with self.subTest(version=version):
                original, sub_columns = self.original_features(version)
                config = {}
                columns = sub_columns + ["qin_30d", "doy_sin", "doy_cos"]
                if version == "v9":
                    config["high_qin30_threshold_train"] = original["high_qin30_threshold_train"]
                    columns += ["qin_90d", "qin_180d", "qin_365d", "qin_30d_std_365d",
                                "qin_30d_iqr_365d", "qin_30d_q90_365d", "high_qin30_rate_365d"]
                actual = build_features(*self.paths, version, feature_config=config)
                pd.testing.assert_frame_equal(
                    actual[columns], original["daily"][columns], check_exact=False,
                    rtol=1e-12, atol=1e-12,
                )
                self.assertEqual(actual.iloc[-1]["date_day"], self.days[-1])
                self.assertNotIn("inflow_next30", actual)

    def test_future_rows_do_not_change_as_of_features(self):
        cutoff = self.days[-21]
        config = {"high_qin30_threshold_train": 500.0}
        before = build_features(*self.paths, "v9", cutoff, config)
        self.inflow.loc[self.inflow.index > len(self.days) - 21, COL_INFLOW] = 1e15
        future = self.rain["date"] > cutoff.strftime("%Y-%m-%d")
        self.rain.loc[future, "area_m2_used"] = 1.0  # Would fail mapping if future rows leaked.
        self.rain.loc[future, "rain_mm_aw"] = 1e10
        self.soil.loc[self.soil["date"] > cutoff.strftime("%Y-%m-%d"), "sm_aw"] = 1000
        self.write_inputs()
        after = build_features(*self.paths, "v9", cutoff, config)
        pd.testing.assert_frame_equal(before, after)
        self.assertEqual(after["date_day"].max(), cutoff)

    def test_final_day_is_retained_and_inflow_lag_excludes_issue_day(self):
        actual = build_features(*self.paths, "v9")
        last = actual.iloc[-1]
        expected = self.inflow[COL_INFLOW].iloc[-181:-1].sum()
        self.assertAlmostEqual(last["qin_180d"], expected)
        self.assertEqual(len(actual), len(self.inflow))

    def test_short_history_and_calendar_gaps_are_rejected(self):
        self.inflow = self.inflow.tail(180)
        self.write_inputs()
        with self.assertRaisesRegex(ValueError, "181 consecutive"):
            build_features(*self.paths, "v9")
        self.inflow = self.inflow.drop(self.inflow.index[-8])
        self.write_inputs()
        with self.assertRaisesRegex(ValueError, "31 consecutive"):
            build_features(*self.paths, "v6")

    def test_missing_subbasin_and_stale_weather_are_rejected(self):
        self.rain = self.rain.iloc[440:].copy()
        self.write_inputs()
        with self.assertRaisesRegex(ValueError, "Rain SB_SW"):
            build_features(*self.paths, "v6")

    def test_requested_day_duplicate_day_and_invalid_date_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "no observation on as_of"):
            build_features(*self.paths, "v6", self.days[-1] + pd.Timedelta(days=1))
        self.inflow = pd.concat([self.inflow, self.inflow.tail(1)], ignore_index=True)
        self.write_inputs()
        with self.assertRaisesRegex(ValueError, "duplicate dates"):
            build_features(*self.paths, "v6")
        self.inflow.loc[0, "month"] = 15
        self.write_inputs()
        with self.assertRaisesRegex(ValueError, "invalid or missing"):
            build_features(*self.paths, "v6")

    def test_month_names_match_numeric_months(self):
        expected = build_features(*self.paths, "v6")
        self.inflow["month"] = self.days.strftime("%b").str.upper()
        self.write_inputs()
        actual = build_features(*self.paths, "v6")
        pd.testing.assert_frame_equal(actual, expected)

    def test_training_threshold_is_required_when_selected(self):
        with self.assertRaisesRegex(ValueError, "missing high_qin30_threshold_train"):
            build_features(*self.paths, "v9", feature_config={
                "feature_columns": ["high_qin30_rate_365d"],
            })


if __name__ == "__main__":
    unittest.main()
