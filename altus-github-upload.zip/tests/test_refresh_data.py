"""A failed local refresh must preserve the last good snapshot and original inputs."""

from datetime import date
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd

from tools.refresh_data import FILES, refresh
from test_ingestion import observations


class LocalRefreshTests(unittest.TestCase):
    def test_resume_and_failure_preserve_previous_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            seed, output = root / 'seed', root / 'out'
            seed.mkdir()
            inflow = pd.DataFrame({'day': [1, 2], 'month': [9, 9], 'year': [2026, 2026], 'inflow adj': [5., 6.]})
            rain = observations(['2026-09-01', '2026-09-02'])
            soil = observations(['2026-09-01', '2026-09-02'], 'sm_aw')
            for name, frame in zip(FILES, (inflow, rain, soil)):
                frame.to_csv(seed / name, index=False)
            original = {p.name: p.read_bytes() for p in seed.iterdir()}
            with patch('tools.refresh_data.collect_inflow', return_value=(pd.DataFrame(), {})), \
                 patch('tools.refresh_data.fetch_subbasin_daily', return_value=(rain, soil, {})), \
                 patch('models.feature_engineering.build_features'):
                result = refresh(seed, output, {}, {}, end=date(2026, 9, 3))
                # Once seeded, a later run resumes from the published full snapshot.
                resumed = refresh(root / 'nonexistent', output, {}, {}, end=date(2026, 9, 3))
            self.assertEqual(result['as_of'], '2026-09-02')
            self.assertEqual(resumed['input_sha256'], result['input_sha256'])
            previous = (output / 'current.json').read_bytes()
            with patch('tools.refresh_data.collect_inflow', side_effect=RuntimeError('source down')):
                with self.assertRaisesRegex(RuntimeError, 'source down'):
                    refresh(seed, output, {}, {}, end=date(2026, 9, 3))
            self.assertEqual((output / 'current.json').read_bytes(), previous)
            self.assertEqual({p.name: p.read_bytes() for p in seed.iterdir()}, original)


if __name__ == '__main__':
    unittest.main()
