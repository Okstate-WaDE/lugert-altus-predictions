"""Offline tests for daily availability and correction-safe history updates."""

from datetime import date, timedelta
from io import BytesIO
import json
from pathlib import Path
import sys
from unittest.mock import MagicMock, patch
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ingestion.gee_daily import choose_pull_start, fetch_subbasin_daily, _initialize, _pull_band
from ingestion.merge import merge_subbasin_history, normalize_subbasin_history
from ingestion.usace_daily import collect_inflow
from ingestion.availability import latest_common_date
from models.feature_engineering import CANONICAL_SUBBASINS


def observations(days, value_col="rain_mm_aw", value=1.0):
    return pd.DataFrame([
        {"date": day, "area_m2_used": basin["representative_area_m2"],
         "subbasin_id": basin["subbasin_id"], value_col: value}
        for day in days for basin in CANONICAL_SUBBASINS
    ])


class HistoryMergeTests(unittest.TestCase):
    def test_corrections_upsert_stable_basins_despite_changed_areas(self):
        old = observations(["2026-09-01", "2026-09-02"], value=2.0)
        old["area_m2_used"] *= 1.001
        new = observations(["2026-09-02", "2026-09-03"], value=4.0)
        new["area_m2_used"] *= 0.999
        merged = merge_subbasin_history(old, new, "rain_mm_aw")
        self.assertEqual(len(merged), 12)
        self.assertFalse(merged.duplicated(["date", "subbasin_id"]).any())
        self.assertTrue((merged.loc[merged["date"] == "2026-09-01", "rain_mm_aw"] == 2).all())
        self.assertTrue((merged.loc[merged["date"] == "2026-09-02", "rain_mm_aw"] == 4).all())
        self.assertEqual(set(merged["area_m2_used"]), {b["representative_area_m2"] for b in CANONICAL_SUBBASINS})

    def test_missing_update_never_erases_observed_data_or_creates_missing_day(self):
        old = observations(["2026-09-01", "2026-09-02"], value=2.0)
        new = observations(["2026-09-02", "2026-09-03"], value=np.nan)
        new.loc[0, "rain_mm_aw"] = 0.0  # An observed zero is a valid correction.
        merged = merge_subbasin_history(old, new, "rain_mm_aw")
        self.assertEqual(len(merged), 8)
        self.assertNotIn("2026-09-03", set(merged["date"]))
        day = merged.loc[merged["date"] == "2026-09-02"].set_index("subbasin_id")
        self.assertEqual(day.loc["SB_SW", "rain_mm_aw"], 0.0)
        self.assertEqual(day.loc["SB_M", "rain_mm_aw"], 2.0)
        self.assertFalse(merged["rain_mm_aw"].isna().any())

    def test_empty_update_preserves_full_history(self):
        old = observations(["2020-01-01", "2026-09-02"])
        result = merge_subbasin_history(old, pd.DataFrame(), "rain_mm_aw")
        self.assertEqual(len(result), 8)
        self.assertEqual(set(result["date"]), {"2020-01-01", "2026-09-02"})

    def test_legacy_duplicates_average_within_each_batch(self):
        previous = observations(["2026-09-01"], value=2.0)
        duplicate = previous.iloc[[0]].copy()
        duplicate["rain_mm_aw"] = 6.0
        result = normalize_subbasin_history(pd.concat([previous, duplicate]), "rain_mm_aw")
        self.assertEqual(len(result), 4)
        self.assertEqual(result.set_index("subbasin_id").loc["SB_SW", "rain_mm_aw"], 4.0)

    def test_noncanonical_basin_is_rejected(self):
        incoming = observations(["2026-09-01"])
        incoming.loc[0, "area_m2_used"] = 123
        with self.assertRaisesRegex(ValueError, "2% canonical"):
            merge_subbasin_history(pd.DataFrame(), incoming, "rain_mm_aw")


class AvailabilityTests(unittest.TestCase):
    def test_common_date_requires_actual_intersection_despite_newer_partial_history(self):
        inflow = pd.DataFrame({'date_day': pd.to_datetime(['2026-09-01', '2026-09-02'])})
        rain = observations(['2026-09-01', '2026-09-03'])
        soil = observations(['2026-09-01', '2026-09-02'], 'sm_aw')
        self.assertEqual(latest_common_date(inflow, rain, soil), date(2026, 9, 1))
        with self.assertRaisesRegex(ValueError, 'No dates'):
            latest_common_date(inflow.iloc[1:], rain, soil)

    def test_unpublished_usace_http_200_page_is_pending_and_referer_is_sent(self):
        report = b'Altus Lake, OK\nMONTHLY LAKE REPORT\nAUG 2026\n31 1546 1546 65000 0 0 0.1 10 0 0\n'
        missing = b'<html><head><title>404: Not Found</title></head></html>'
        with patch('ingestion.usace_daily.urlopen', side_effect=[BytesIO(report), BytesIO(missing)]) as request:
            rows, status = collect_inflow(date(2026, 8, 31), date(2026, 9, 23))
        self.assertEqual(rows.date_day.dt.date.tolist(), [date(2026, 8, 31)])
        self.assertEqual(status['unpublished_months'], ['2026-09-01'])
        self.assertIn('proj=ALTU', request.call_args.args[0].get_header('Referer'))
        self.assertEqual(len(status['sources']), 1)

    def test_unexpected_server_page_is_an_error_not_a_missing_report(self):
        with patch('ingestion.usace_daily.urlopen', return_value=BytesIO(b'<html>Access denied</html>')):
            with self.assertRaisesRegex(ValueError, 'not an Altus'):
                collect_inflow(date(2026, 9, 1), date(2026, 9, 23))


class EarthEngineCollectionTests(unittest.TestCase):
    def test_resume_closes_long_outage_and_always_has_at_least_sixty_day_window(self):
        end = date(2026, 9, 23)
        self.assertEqual(choose_pull_start(end, lookback_days=7), end - timedelta(days=59))
        self.assertEqual(choose_pull_start(end, "2025-12-31", 120), date(2025, 12, 1))

    def test_collection_delay_reports_pending_yesterday_without_synthetic_rows(self):
        ee = MagicMock()
        def pull(*args):
            start, end, value_col = args[3], args[4], args[6]
            days = pd.date_range(start, end).strftime("%Y-%m-%d")
            return observations(days, value_col)
        with patch("ingestion.gee_daily._initialize", return_value=ee), \
             patch("ingestion.gee_daily._collection_range", return_value=(date(1950, 1, 2), date(2026, 9, 16))), \
             patch("ingestion.gee_daily._subbasins", return_value="watershed_polygons"), \
             patch("ingestion.gee_daily._pull_band", side_effect=pull) as fetch:
            rain, soil, meta = fetch_subbasin_daily("2026-09-01", "2026-09-23", {})
        self.assertEqual(meta["actual_end_date"], "2026-09-16")
        self.assertEqual(meta["lag_days"], 7)
        self.assertFalse(meta["requested_day_available"])
        self.assertIn("2026-09-23", meta["pending_dates"])
        self.assertEqual(len(meta["pending_dates"]), 7)
        self.assertEqual(len(rain), 16 * 4)
        self.assertEqual(len(soil), 16 * 4)
        self.assertEqual(fetch.call_args_list[0].args[-1], 1000.0)
        self.assertEqual(fetch.call_args_list[1].args[-1], 1.0)
        self.assertEqual(fetch.call_args_list[0].args[-2], 10000)
        self.assertEqual(fetch.call_args_list[0].args[2], "watershed_polygons")

    def test_fully_unavailable_window_returns_empty_frames_and_no_extraction(self):
        with patch("ingestion.gee_daily._initialize", return_value=MagicMock()), \
             patch("ingestion.gee_daily._collection_range", return_value=(date(1950, 1, 2), date(2026, 9, 16))), \
             patch("ingestion.gee_daily._pull_band") as fetch:
            rain, soil, meta = fetch_subbasin_daily("2026-09-23", "2026-09-23", {})
        fetch.assert_not_called()
        self.assertTrue(rain.empty)
        self.assertTrue(soil.empty)
        self.assertEqual(meta["pending_dates"], ["2026-09-23"])
        self.assertIsNone(meta["actual_end_date"])
        self.assertEqual(meta["collection_lag_days"], 7)

    def test_missing_basin_remains_pending_and_backfill_is_chunked(self):
        def pull(*args):
            start, end, value_col = args[3], args[4], args[6]
            frame = observations(pd.date_range(start, end).strftime("%Y-%m-%d"), value_col)
            if value_col == "sm_aw":
                frame = frame.loc[~((frame["date"] == "2026-09-23") & (frame["subbasin_id"] == "SB_SW"))]
            return frame
        with patch("ingestion.gee_daily._initialize", return_value=MagicMock()), \
             patch("ingestion.gee_daily._collection_range", return_value=(date(1950, 1, 2), date(2026, 9, 23))), \
             patch("ingestion.gee_daily._subbasins"), \
             patch("ingestion.gee_daily._pull_band", side_effect=pull) as fetch:
            _, _, meta = fetch_subbasin_daily("2026-08-01", "2026-09-23", {})
        self.assertEqual(fetch.call_count, 4)  # Two 31-day-or-smaller chunks, two variables.
        self.assertEqual(meta["actual_end_date"], "2026-09-22")
        self.assertEqual(meta["pending_dates"], ["2026-09-23"])

    def test_service_account_key_stays_in_memory(self):
        ee = MagicMock()
        fake_key = {"client_email": "unit-test@example.invalid", "private_key": "not-a-real-key"}
        with patch.dict(sys.modules, {"ee": ee}):
            _initialize({"project_id": "lugert-altus"}, fake_key)
        kwargs = ee.ServiceAccountCredentials.call_args.kwargs
        self.assertEqual(json.loads(kwargs["key_data"]), fake_key)
        self.assertNotIn("key_file", kwargs)
        ee.Initialize.assert_called_once_with(credentials=ee.ServiceAccountCredentials.return_value, project="lugert-altus")

    def test_pull_uses_exclusive_next_day_and_drops_null_polygon_values(self):
        ee = MagicMock()
        collection = MagicMock()
        payload = {"features": [
            {"properties": {"date": "2026-09-16", "area_m2_used": CANONICAL_SUBBASINS[0]["representative_area_m2"], "value": 0.0}},
            {"properties": {"date": "2026-09-16", "area_m2_used": CANONICAL_SUBBASINS[1]["representative_area_m2"], "value": None}},
        ]}
        ee.FeatureCollection.return_value.getInfo.return_value = payload
        result = _pull_band(ee, collection, "polygons", date(2026, 9, 16), date(2026, 9, 16),
                            "total_precipitation_sum", "rain_mm_aw", 10000, 1000)
        collection.filterDate.assert_called_once_with("2026-09-16", "2026-09-17")
        self.assertEqual(len(result), 1)
        self.assertEqual(result.iloc[0]["rain_mm_aw"], 0)


if __name__ == "__main__":
    unittest.main()
