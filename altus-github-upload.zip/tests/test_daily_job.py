from datetime import date
from io import BytesIO
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pandas as pd

from ingestion import daily_job
from ingestion.usace_daily import parse_report, merge_inflow
from models.feature_engineering import CANONICAL_SUBBASINS


class FakeS3:
    def __init__(self, objects):
        self.objects = objects
        self.writes = []

    def get_object(self, Bucket, Key):
        return {'Body': BytesIO(self.objects[Key])}

    def put_object(self, Bucket, Key, Body, **kwargs):
        self.objects[Key] = Body
        self.writes.append(Key)

    def download_file(self, bucket, key, path):
        Path(path).write_bytes(self.objects[key])

    def upload_file(self, path, bucket, key):
        self.objects[key] = Path(path).read_bytes()
        self.writes.append(key)


class DailyJobTests(unittest.TestCase):
    def setUp(self):
        self.inflow = pd.DataFrame({'day': [1, 2], 'month': [1, 1], 'year': [2025, 2025],
                                    'inflow adj': [10., 20.], 'rainfall inches (7A to Dam)': [0., 0.],
                                    'rainfall inches (7A to BSN)': [0., 0.]})
        self.rain = pd.DataFrame([{'date': '2025-01-02', 'area_m2_used': b['representative_area_m2'],
                                  'rain_mm_aw': 2.} for b in CANONICAL_SUBBASINS])
        self.soil = self.rain.rename(columns={'rain_mm_aw': 'sm_aw'})
        objects = {'config/daily.json': b'{"gee":{}}', 'inputs/current.json': b'{"input_prefix":"inputs/"}'}
        for name, frame in zip(daily_job.INPUT_FILES, [self.inflow, self.rain, self.soil]):
            objects['inputs/' + name] = frame.to_csv(index=False).encode()
        self.s3 = FakeS3(objects)
        self.secrets = unittest.mock.Mock()
        self.secrets.get_secret_value.return_value = {'SecretString': '{}'}

    def train_stub(self, args, **kwargs):
        output = Path(args[args.index('--output-dir') + 1])
        output.mkdir()
        (output / 'model.joblib').write_bytes(b'validated model stub')
        (output / 'metadata.json').write_text('{}')

    def test_both_models_verified_before_manifest_promotion(self):
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(daily_job, 'fetch_subbasin_daily', return_value=(self.rain, self.soil, {'lag_days': 1})), \
             patch.object(daily_job, 'collect_inflow', return_value=(self.inflow, {})), \
             patch.object(daily_job.subprocess, 'run', side_effect=self.train_stub) as train, \
             patch.object(daily_job, 'load_bundle', return_value={}), \
             patch.object(daily_job, 'predict', return_value={'y_pred_next30': 1.}):
            result = daily_job.run(self.s3, self.secrets, 'bucket', 'config/daily.json', 'secret', Path(tmp))
        self.assertEqual(train.call_count, 2)
        self.assertEqual(result['status'], 'published')
        pointer = json.loads(self.s3.objects['inputs/current.json'])
        for key in pointer['model_keys'].values():
            self.assertIn(key, self.s3.objects)
            self.assertLess(self.s3.writes.index(key), self.s3.writes.index('inputs/current.json'))
        self.assertEqual(pointer['as_of'], '2025-01-02')

    def test_failed_training_does_not_change_manifest(self):
        previous = self.s3.objects['inputs/current.json']
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(daily_job, 'fetch_subbasin_daily', return_value=(self.rain, self.soil, {})), \
             patch.object(daily_job, 'collect_inflow', return_value=(self.inflow, {})), \
             patch.object(daily_job.subprocess, 'run', side_effect=RuntimeError('training failed')):
            with self.assertRaisesRegex(RuntimeError, 'training failed'):
                daily_job.run(self.s3, self.secrets, 'bucket', 'config/daily.json', 'secret', Path(tmp))
        self.assertEqual(self.s3.objects['inputs/current.json'], previous)

    def test_report_parser_reads_original_columns_and_preserves_missing(self):
        report = 'Altus Lake, OK\nMONTHLY LAKE REPORT\nJAN 2025\n' \
                 '1 1546.29 1546.30 65904 0 0 0.096 10 0.00 0.00\n' \
                 '2 1546.30 1546.34 66062 0 0 0.063 -- -- --\n'
        result = parse_report(report, 2025, 1)
        self.assertEqual(len(result), 1)
        self.assertEqual(result.iloc[0]['inflow adj'], 10)
        with self.assertRaises(ValueError):
            parse_report(report, 2025, 2)
        corrected = result.copy()
        corrected['inflow adj'] = 15.
        combined = merge_inflow(self.inflow, corrected)
        self.assertEqual(combined['inflow adj'].tolist(), [15., 20.])


if __name__ == '__main__':
    unittest.main()
