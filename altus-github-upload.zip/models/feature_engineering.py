"""Prediction-time features matching the original Altus v6 and v9 scripts.

This module only reads observations and constructs backward-looking features.
It never creates future targets, fits an estimator, or writes plots/audit files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


CANONICAL_SUBBASINS = [
    {"subbasin_id": "SB_SW", "representative_area_m2": 878470000.0},
    {"subbasin_id": "SB_M", "representative_area_m2": 937450000.0},
    {"subbasin_id": "SB_SE", "representative_area_m2": 1064410000.0},
    {"subbasin_id": "SB_NW", "representative_area_m2": 1405090000.0},
]
MONTH_MAP = dict(zip(
    ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
    range(1, 13),
))
COL_INFLOW = "inflow adj"
COL_RAIN_DAM = "rainfall inches (7A to Dam)"
COL_RAIN_BSN = "rainfall inches (7A to BSN)"


def _require_columns(frame: pd.DataFrame, columns: list[str], label: str) -> None:
    missing = sorted(set(columns) - set(frame.columns))
    if missing:
        raise ValueError(f"{label} CSV is missing required columns: {', '.join(missing)}")


def _issue_date(value: Any) -> pd.Timestamp:
    try:
        result = pd.Timestamp(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("as_of must be a valid calendar date (YYYY-MM-DD)") from exc
    if pd.isna(result) or result.tzinfo is not None or result != result.normalize():
        raise ValueError("as_of must be a calendar date without a time or timezone")
    return result


def _check_daily_history(dates: pd.Series, cutoff: pd.Timestamp, days: int, label: str) -> None:
    required = pd.date_range(end=cutoff, periods=days, freq="D")
    missing = required.difference(pd.DatetimeIndex(dates))
    if len(missing):
        examples = ", ".join(d.strftime("%Y-%m-%d") for d in missing[:3])
        raise ValueError(
            f"{label} requires {days} consecutive daily observations through "
            f"{cutoff:%Y-%m-%d}; {len(missing)} dates are absent (for example {examples})"
        )


def _inflow_history_days(version: str, config: dict[str, Any]) -> int:
    selected = config.get("feature_columns")
    if selected is None:
        return 31 if version == "v6" else 181
    days = 31
    for window in (30, 90, 180, 365):
        if f"qin_{window}d" in selected:
            days = max(days, window + 1)
    annual_qin30 = {
        "qin_30d_std_365d", "qin_30d_iqr_365d", "qin_30d_q90_365d", "high_qin30_rate_365d"
    }
    if annual_qin30.intersection(selected):
        # A full 365-day distribution of 30-day trailing sums needs 395 rows.
        days = max(days, 395)
    for name in selected:
        if name.startswith("rain_altu_") and name.endswith("d"):
            try:
                days = max(days, int(name.rsplit("_", 1)[1][:-1]))
            except ValueError:
                pass
    return days


def _read_inflow(path: str | Path, version: str, cutoff: Any) -> tuple[pd.DataFrame, pd.Timestamp]:
    daily = pd.read_csv(path)
    required = ["year", "month", "day", COL_INFLOW]
    if version == "v9":
        required += [COL_RAIN_DAM, COL_RAIN_BSN]
    _require_columns(daily, required, "Inflow")
    daily = daily[required].copy()
    months = pd.to_numeric(daily["month"], errors="coerce")
    names = daily["month"].astype("string").str.strip().str.upper().map(MONTH_MAP)
    months = months.fillna(names)
    daily["date_day"] = pd.to_datetime(
        dict(year=pd.to_numeric(daily["year"], errors="coerce"),
             month=months, day=pd.to_numeric(daily["day"], errors="coerce")),
        errors="coerce",
    )
    if daily["date_day"].isna().any():
        raise ValueError("Inflow CSV contains invalid or missing year/month/day values")
    if daily.empty:
        raise ValueError("Inflow CSV has no observations")
    cutoff = _issue_date(cutoff) if cutoff is not None else daily["date_day"].max()
    # Cut off every raw source before numeric cleaning, mapping, or rolling.
    daily = daily.loc[daily["date_day"] <= cutoff].copy()
    if not (daily["date_day"] == cutoff).any():
        raise ValueError(f"Inflow CSV has no observation on as_of {cutoff:%Y-%m-%d}")
    if daily["date_day"].duplicated().any():
        raise ValueError("Inflow CSV contains duplicate dates; supply exactly one row per day")
    daily = daily.sort_values("date_day").reset_index(drop=True)
    try:
        daily[COL_INFLOW] = daily[COL_INFLOW].astype(float)
    except (TypeError, ValueError) as exc:
        raise ValueError("Inflow CSV contains non-numeric inflow adj values") from exc
    if np.isinf(daily[COL_INFLOW]).any():
        raise ValueError("Inflow CSV contains infinite inflow values")
    daily["year"] = daily["date_day"].dt.year
    daily["month"] = daily["date_day"].dt.month
    daily["day"] = daily["date_day"].dt.day
    return daily, cutoff


def _read_subbasin(
    path: str | Path, value_col: str, label: str, cutoff: pd.Timestamp,
    canonical: pd.DataFrame, tolerance: float,
) -> pd.DataFrame:
    frame = pd.read_csv(path)
    _require_columns(frame, ["date", "area_m2_used", value_col], label)
    dates = pd.to_datetime(frame["date"], errors="coerce", format="mixed")
    if dates.isna().any():
        raise ValueError(f"{label} CSV contains invalid or missing dates")
    if not pd.api.types.is_datetime64_dtype(dates.dtype):
        raise ValueError(f"{label} CSV dates must not contain timezones")
    if not dates.eq(dates.dt.normalize()).all():
        raise ValueError(f"{label} CSV dates must identify whole calendar days")
    frame["date_day"] = dates
    frame = frame.loc[frame["date_day"] <= cutoff, ["date_day", "area_m2_used", value_col]].copy()
    frame["area_m2_used"] = pd.to_numeric(frame["area_m2_used"], errors="coerce")
    frame[value_col] = pd.to_numeric(frame[value_col], errors="coerce")
    if frame["area_m2_used"].isna().any() or (frame["area_m2_used"] <= 0).any():
        raise ValueError(f"{label} CSV contains invalid subbasin areas")
    if np.isinf(frame[["area_m2_used", value_col]]).any().any():
        raise ValueError(f"{label} CSV contains infinite values")
    area_to_basin = {}
    for area in frame["area_m2_used"].unique():
        idx = (canonical["representative_area_m2"] - area).abs().idxmin()
        basin = canonical.loc[idx]
        diff_pct = abs(basin["representative_area_m2"] - area) / area * 100.0
        if diff_pct > tolerance:
            raise ValueError(
                f"Canonical subbasin match for {label} area {area:.6f} is "
                f"{diff_pct:.3f}% away, above tolerance {tolerance:.3f}%"
            )
        area_to_basin[area] = basin["subbasin_id"]
    frame["subbasin"] = frame["area_m2_used"].map(area_to_basin)
    for basin in canonical["subbasin_id"]:
        basin_dates = frame.loc[frame["subbasin"] == basin, "date_day"]
        _check_daily_history(basin_dates, cutoff, 30, f"{label} {basin}")
    grouped = frame.groupby(["date_day", "subbasin"], as_index=False)[value_col].mean()
    return grouped.pivot_table(
        index="date_day", columns="subbasin", values=value_col, aggfunc="mean"
    ).reindex(columns=canonical["subbasin_id"].tolist()).sort_index()


def _subbasin_features(rain: pd.DataFrame, soil: pd.DataFrame, canonical: pd.DataFrame) -> pd.DataFrame:
    basins = canonical["subbasin_id"].tolist()
    feats = pd.DataFrame(index=rain.index.union(soil.index).sort_values())
    for basin in basins:
        rain_s = rain[basin].reindex(feats.index).astype(float).fillna(0.0)
        soil_s = soil[basin].reindex(feats.index).astype(float)
        for window in (7, 30):
            feats[f"arain_{basin}_{window}d"] = rain_s.rolling(window, min_periods=1).sum()
            feats[f"asm_{basin}_{window}d"] = soil_s.rolling(window, min_periods=1).mean()
    weights = canonical.set_index("subbasin_id")["representative_area_m2"].reindex(basins).astype(float)
    weights = weights / weights.sum()
    for prefix in ("arain", "asm"):
        for window in (7, 30):
            columns = [f"{prefix}_{basin}_{window}d" for basin in basins]
            # Preserve the original scripts' pandas label alignment exactly.
            # Their basin-only weight labels do not align to prefixed feature
            # labels, so these currently unselected weighted columns are zero.
            # Correcting this requires retraining and a new feature schema.
            feats[f"{prefix}_weighted_{window}d"] = feats[columns].mul(weights, axis=1).sum(axis=1)
    feats["arain_spread_7d"] = feats[[f"arain_{b}_7d" for b in basins]].std(axis=1)
    feats["asm_spread_30d"] = feats[[f"asm_{b}_30d" for b in basins]].std(axis=1)
    return feats.rename_axis("date_day").reset_index()


def build_features(
    data_path: str | Path,
    rain_path: str | Path,
    sm_path: str | Path,
    model_version: str,
    as_of: Any = None,
    feature_config: dict[str, Any] | None = None,
) -> pd.DataFrame:
    """Return observations through ``as_of`` with features and a ``date_day`` column.

    ``as_of`` defaults to the newest inflow date. The requested date must exist
    in every source. At least 31 inflow dates (v6) or 181 (v9), and 30 dates for
    each rain/soil subbasin, must be supplied, including the issue date. Optional
    saved ``feature_columns`` may increase the necessary history. Trailing
    missing values retain the original zero-fill/mean-imputation behavior.
    """
    version = str(model_version).lower()
    if version not in {"v6", "v9"}:
        raise ValueError("model_version must be v6 or v9")
    config = dict(feature_config or {})
    canonical = pd.DataFrame(config.get("canonical_subbasins", CANONICAL_SUBBASINS))
    tolerance = float(config.get("subbasin_area_tolerance_pct", 2.0))
    daily, cutoff = _read_inflow(data_path, version, as_of)
    _check_daily_history(daily["date_day"], cutoff, _inflow_history_days(version, config), "Inflow")
    rain = _read_subbasin(rain_path, "rain_mm_aw", "Rain", cutoff, canonical, tolerance)
    soil = _read_subbasin(sm_path, "sm_aw", "Soil moisture", cutoff, canonical, tolerance)
    daily = daily.merge(_subbasin_features(rain, soil, canonical), on="date_day", how="left")
    qin_prior = daily[COL_INFLOW].fillna(0.0).shift(1)
    for window in ((30,) if version == "v6" else (30, 90, 180, 365)):
        daily[f"qin_{window}d"] = qin_prior.rolling(window, min_periods=1).sum()
    if version == "v6" and config.get("include_year_feature", False):
        if config.get("train_start_year") is None:
            raise ValueError("The model bundle must store train_start_year for the year feature")
        daily[config.get("year_feature_col", "years_since_train_start")] = (
            daily["year"] - int(config["train_start_year"])
        )
    if version == "v9":
        qin30 = daily["qin_30d"]
        rolling = qin30.rolling(365, min_periods=30)
        daily["qin_30d_std_365d"] = rolling.std()
        daily["qin_30d_iqr_365d"] = rolling.quantile(0.75) - rolling.quantile(0.25)
        daily["qin_30d_q90_365d"] = rolling.quantile(0.90)
        threshold = config.get("high_qin30_threshold_train")
        if threshold is not None:
            daily["high_qin30_rate_365d"] = (
                (qin30 >= float(threshold)).astype(float).rolling(365, min_periods=30).mean()
            )
        elif "high_qin30_rate_365d" in config.get("feature_columns", []):
            raise ValueError("The model bundle is missing high_qin30_threshold_train")
        daily[COL_RAIN_DAM] = pd.to_numeric(daily[COL_RAIN_DAM], errors="coerce").fillna(0.0)
        daily[COL_RAIN_BSN] = pd.to_numeric(daily[COL_RAIN_BSN], errors="coerce").fillna(0.0)
        daily["rainfall_altu_combined"] = daily[COL_RAIN_DAM] + daily[COL_RAIN_BSN]
        rainfall_sources = {
            "rain_altu_dam": daily[COL_RAIN_DAM],
            "rain_altu_bsn": daily[COL_RAIN_BSN],
            "rain_altu_combined": daily["rainfall_altu_combined"],
        }
        for name, series in rainfall_sources.items():
            for window in config.get("rainfall_rolling_windows", [7, 14, 30, 45]):
                daily[f"{name}_{window}d"] = series.rolling(int(window), min_periods=1).sum()
    daily["doy"] = daily["date_day"].dt.dayofyear
    daily["doy_sin"] = np.sin(2 * np.pi * daily["doy"] / 365.25)
    daily["doy_cos"] = np.cos(2 * np.pi * daily["doy"] / 365.25)
    return daily
