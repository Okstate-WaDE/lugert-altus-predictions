# Altus prediction deployment from GitHub

Prepared for https://github.com/Okstate-WaDE/lugert-altus-predictions, branch `main`.
This is an upload package, not a checkout: the existing repository contents have not been reviewed or merged.
Review overlapping files before adding these files to your repository root, including `.github/workflows/`.

## Code and trained models

`artifacts/v6/model.joblib` and `artifacts/v9/model.joblib` are deliberately tracked in Git and copied into the image. Their companion metadata supplies checksums and runtime versions, checked before loading. These are the Docker-trained September 24, 2026 bundles: 11,507 eligible rows, with observed targets through August 31. They are not newly retrained models. Only commit trusted model bundles: joblib loading executes pickle data.

Lambda uses the image's model when `MODEL_SOURCE=image`. The existing S3 `inputs/current.json` still selects input prefix and forecast date; its `model_keys` are ignored in image mode. The existing S3 model files can remain. Input CSVs, credentials, and generated predictions are excluded from this package. The build does not train anything.

## Administrator setup (replaces the CodeBuild role request)

1. In account 872238288316, configure the GitHub OIDC provider `https://token.actions.githubusercontent.com` with audience `sts.amazonaws.com` if not already present.
2. Create a role such as `altus-github-image-build`, using `aws/github-trust.json` as its trust policy and `aws/github-ecr-access.json` as its permissions policy. Trust is limited to this repository's `main` branch. No static AWS keys, S3 write access, or Lambda deployment permissions are needed by the workflow.
3. Return the role ARN. In GitHub Settings > Secrets and variables > Actions > Variables, create `AWS_BUILD_ROLE_ARN` with that ARN.
4. Separately provide a Lambda execution role trusted by `lambda.amazonaws.com`, with AWSLambdaBasicExecutionRole and `aws/lambda-v6-access.json`. The deploying user needs permission to create/configure Lambda and pass this role, plus the ECR permissions required to select the image and grant Lambda image retrieval. The GitHub role does not grant those user permissions.

Reference: https://github.com/aws-actions/configure-aws-credentials and https://docs.aws.amazon.com/lambda/latest/dg/images-create.html

## Build only when requested

Commit the files to `main`, then open Actions > Build prediction image > Run workflow, choosing `main`.
The workflow builds a Linux amd64 image, checks both packaged bundles, runs handler tests, then assumes the AWS role and pushes a uniquely tagged image into `872238288316.dkr.ecr.us-east-2.amazonaws.com/altus-prediction`.
The image URI and digest appear in the run summary. The workflow does not create or update Lambda and does not run on a schedule.

## First Lambda prediction (v6)

In the Lambda console in us-east-2, create a function named `altus-v6` using Container image. Select the image from the workflow and architecture x86_64. Use the administrator-provided execution role. Leave the image command and entrypoint at their defaults. Set memory to 2048 MB, timeout to 5 minutes, and ephemeral storage to 2048 MB.

Configure these environment variables:

| Name | Value |
|---|---|
| MODEL_SOURCE | image |
| MODEL_VERSION | v6 |
| INPUT_BUCKET | altus-s3-bucket |
| INPUT_PREFIX | inputs/ |
| DATA_MANIFEST_KEY | inputs/current.json |
| OUTPUT_BUCKET | altus-s3-bucket |
| OUTPUT_PREFIX | outputs/ |

Test with `{}`. Expect `status: ok`, `model_source: image`, a model checksum, a prediction, and a result S3 URI. With the currently prepared inputs, the forecast origin is August 31, 2026. No current-day forecast is implied.

After v6 passes, create v9 using the same image and MODEL_VERSION=v9, with equivalent S3 output permissions for outputs/v9/*.

Updating a committed model requires rebuilding the image and explicitly deploying the new image to Lambda. Daily collection and retraining are deferred.
