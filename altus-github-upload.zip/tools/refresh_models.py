"""Recreate portable training copies without rewriting the model algorithms.

Run with the directory containing the original ``Python altus_model_v*.py`` files.
The AST check permits only the documented I/O and worker-count changes.
"""

import argparse
import ast
import hashlib
import json
from pathlib import Path
import re


PACKAGE_DIR = Path(__file__).resolve().parents[1]
PATH_ENV = {
    "DATA_PATH": "ALTUS_DATA_PATH",
    "OUT_DIR": "ALTUS_OUT_DIR",
    "SUBBASIN_RAIN_PATH": "ALTUS_SUBBASIN_RAIN_PATH",
    "SUBBASIN_SM_PATH": "ALTUS_SUBBASIN_SM_PATH",
}


class NormalizePortabilityChanges(ast.NodeTransformer):
    """Ignore only the allowed differences when comparing original/copy ASTs."""

    def visit_Import(self, node):
        if len(node.names) == 1 and node.names[0].name == "os":
            return None
        return node

    def visit_Assign(self, node):
        if (len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id in PATH_ENV):
            node.value = ast.Constant(value="PORTABLE_PATH")
            return node
        return self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id == "resolve_first_existing_path":
            node.args = node.args[:1]
        return self.generic_visit(node)

    def visit_keyword(self, node):
        if node.arg == "n_jobs" and isinstance(node.value, ast.UnaryOp):
            if isinstance(node.value.op, ast.USub) and ast.literal_eval(node.value) == -1:
                node.value = ast.Constant(value=1)
        return self.generic_visit(node)

    def visit_Constant(self, node):
        if isinstance(node.value, str):
            node.value = node.value.replace(" and desktop fallback", "")
        return node


def assert_model_logic_preserved(original, portable):
    normalized = []
    for source in (original, portable):
        tree = NormalizePortabilityChanges().visit(ast.parse(source))
        normalized.append(ast.dump(tree, include_attributes=False))
    if normalized[0] != normalized[1]:
        raise ValueError("Unexpected model logic change detected by AST comparison")


def adapt_source(original):
    source, count = re.subn(r"^from pathlib import Path$", "from pathlib import Path\nimport os", original, flags=re.M)
    if count != 1:
        raise ValueError("Expected exactly one pathlib import")
    for name, env in PATH_ENV.items():
        source, count = re.subn(
            rf"^{name}\s*=\s*Path\([^\n]+\)$",
            f'{name} = Path(os.environ["{env}"])', source, flags=re.M,
        )
        if count != 1:
            raise ValueError(f"Expected exactly one {name} path assignment")
    for name in ("SUBBASIN_RAIN_PATH", "SUBBASIN_SM_PATH"):
        source, count = re.subn(
            rf"resolve_first_existing_path\(\s*{name},\s*Path\([^\n]+\)\s*\)",
            f"resolve_first_existing_path({name})", source,
        )
        if count != 1:
            raise ValueError(f"Expected exactly one desktop fallback for {name}")
    source = source.replace(" and desktop fallback", "")
    source, worker_edits = re.subn(r"\bn_jobs\s*=\s*-1\b", "n_jobs=1", source)
    if "C:\\" in source or "desktop fallback" in source:
        raise ValueError("Unconverted local fallback path remains")
    assert_model_logic_preserved(original, source)
    compile(source, "<portable model>", "exec")
    return source, worker_edits


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, required=True)
    args = parser.parse_args()
    destination = PACKAGE_DIR / "models"
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for version in ("v6", "v9"):
        original_path = args.source_dir / f"Python altus_model_{version}.py"
        original_bytes = original_path.read_bytes()
        original = original_bytes.decode("utf-8-sig").replace("\r\n", "\n")
        portable, worker_edits = adapt_source(original)
        target = destination / f"model_{version}.py"
        target.write_text(portable, encoding="utf-8", newline="\n")
        records.append({
            "model_version": version,
            "source_file": original_path.name,
            "source_sha256": hashlib.sha256(original_bytes).hexdigest(),
            "portable_file": target.name,
            "portable_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
            "n_jobs_minus_one_to_one_count": worker_edits,
            "ast_model_logic_preserved": True,
        })
    provenance = {
        "changes": [
            "Import os and read four required file/directory paths from environment variables.",
            "Remove both Windows desktop CSV fallback paths and their error-message references.",
            "Use n_jobs=1 in place of n_jobs=-1 (six v6 estimators; v9 already uses 1).",
            "All other Python AST nodes, features, hyperparameters, splits and output logic are preserved.",
            "Normalize source text to UTF-8 without BOM and LF line endings.",
        ],
        "environment_variables": PATH_ENV,
        "models": records,
    }
    (destination / "provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
