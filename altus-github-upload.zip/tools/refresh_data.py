"""Refresh a full local training dataset using the same sources as the AWS job."""

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import sys
import uuid
from zoneinfo import ZoneInfo

PACKAGE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_DIR))

import pandas as pd
from ingestion.availability import complete_dates, latest_common_date
from ingestion.gee_daily import choose_pull_start, fetch_subbasin_daily
from ingestion.merge import merge_subbasin_history
from ingestion.usace_daily import collect_inflow, merge_inflow, normalize_inflow

FILES = ('ALTU_ALL.csv', 'ERA5Land_daily_area_weighted_subbasin_rainfall.csv',
         'ERA5Land_daily_area_weighted_subbasin_soil_moisture.csv')


def refresh(input_dir, output_dir, config, credential_data, end=None):
    end = end or (datetime.now(ZoneInfo(config.get('timezone', 'America/Chicago'))).date() - timedelta(days=1))
    input_dir, output_dir = Path(input_dir).resolve(), Path(output_dir).resolve()
    pointer = output_dir / 'current.json'
    if pointer.is_file():
        previous = json.loads(pointer.read_text(encoding='utf-8'))
        input_dir = (output_dir / previous['data_directory']).resolve()
        if not input_dir.is_relative_to(output_dir):
            raise ValueError('Previous snapshot path is outside the refresh directory')
    frames = [pd.read_csv(input_dir / name) for name in FILES]
    old_inflow, old_rain, old_soil = frames
    old_dates = {
        'inflow': normalize_inflow(old_inflow).date_day.max().date(),
        'rain': pd.to_datetime(old_rain.date).max().date(),
        'soil': pd.to_datetime(old_soil.date).max().date(),
    }
    lookback = int(config.get('lookback_days', 120))
    print(f'Requesting inflow through {end}...', flush=True)
    incoming_inflow, inflow_status = collect_inflow(
        choose_pull_start(end, old_dates['inflow'], lookback), end, config.get('usace', {}))
    print(f'Collected {len(incoming_inflow)} inflow rows. Requesting watershed weather...', flush=True)
    incoming_rain, incoming_soil, weather_status = fetch_subbasin_daily(
        choose_pull_start(end, min(old_dates['rain'], old_dates['soil']), lookback), end,
        config.get('gee', {}), credential_data)
    inflow = merge_inflow(old_inflow, incoming_inflow)
    rain = merge_subbasin_history(old_rain, incoming_rain, 'rain_mm_aw')
    soil = merge_subbasin_history(old_soil, incoming_soil, 'sm_aw')
    inflow = inflow.loc[inflow.date_day <= pd.Timestamp(end)].copy()
    rain = rain.loc[pd.to_datetime(rain.date) <= pd.Timestamp(end)].copy()
    soil = soil.loc[pd.to_datetime(soil.date) <= pd.Timestamp(end)].copy()
    if inflow.empty or inflow.date_day.duplicated().any() or not inflow.date_day.diff().dropna().eq(pd.Timedelta(days=1)).all():
        raise ValueError('Inflow history has missing or duplicate calendar dates; do not train on compressed time')
    as_of = latest_common_date(inflow, rain, soil)
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    snapshot = output_dir / 'snapshots' / run_id
    snapshot.mkdir(parents=True)
    paths = [snapshot / name for name in FILES]
    inflow.drop(columns='date_day').to_csv(paths[0], index=False)
    rain.to_csv(paths[1], index=False)
    soil.to_csv(paths[2], index=False)
    # Validate the trailing history used by both live models before publishing.
    from models.feature_engineering import build_features
    for model_version in ('v6', 'v9'):
        build_features(*paths, model_version, as_of=as_of.isoformat())
    metadata = {
        'status': 'ready', 'run_id': run_id, 'requested_date': end.isoformat(),
        'as_of': as_of.isoformat(), 'lag_days': (end - as_of).days,
        'data_directory': snapshot.relative_to(output_dir).as_posix(),
        'previous_latest': {k: v.isoformat() for k, v in old_dates.items()},
        'latest': {'inflow': inflow.date_day.max().date().isoformat(),
                   'rain': max(complete_dates(rain, 'rain_mm_aw')).isoformat(),
                   'soil': max(complete_dates(soil, 'sm_aw')).isoformat()},
        'rows': dict(zip(('inflow', 'rain', 'soil'), map(len, (inflow, rain, soil)))),
        'input_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'weather': weather_status, 'inflow': inflow_status,
    }
    encoded = json.dumps(metadata, indent=2, allow_nan=False)
    (snapshot / 'refresh_metadata.json').write_text(encoded, encoding='utf-8')
    temporary = output_dir / f'.current-{run_id}.json'
    temporary.write_text(encoded, encoding='utf-8')
    temporary.replace(pointer)
    print(json.dumps({'status': 'ready', 'data_directory': str(snapshot),
                      'latest': metadata['latest'], 'as_of': metadata['as_of']}, indent=2), flush=True)
    return metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--config', type=Path, default=PACKAGE_DIR / 'config/daily.example.json')
    parser.add_argument('--key-file', type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8-sig'))
    credential_data = json.loads(args.key_file.read_text(encoding='utf-8-sig'))
    refresh(args.input_dir, args.output_dir, config, credential_data)


if __name__ == '__main__':
    main()
