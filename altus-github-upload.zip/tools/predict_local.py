"""Run the exact Lambda prediction code against local CSVs, without AWS."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from inference import load_bundle, predict


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", choices=("v6", "v9"), required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--rain", type=Path, required=True)
    parser.add_argument("--soil", type=Path, required=True)
    parser.add_argument("--as-of")
    args = parser.parse_args()
    bundle = load_bundle(args.model, args.version)
    result = predict(bundle, args.data, args.rain, args.soil, as_of=args.as_of)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
