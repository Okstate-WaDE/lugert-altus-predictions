"""Evaluate the original model, then refit its RF on all usable labeled data.

Run in the same container image used by Lambda so native libraries and serialized
estimator versions match. Training and plotting occur here, never in the handler.
The deployed estimator uses all current labeled rows; benchmark split reports and
their residual intervals are retained as diagnostics from the original estimator.
"""

import argparse
from datetime import date, datetime, timedelta, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import runpy
import sys


PACKAGE_DIR = Path(__file__).resolve().parents[1]
INTERVAL_KEYS = (
    "qlo90_map", "qhi90_map", "glo90", "ghi90",
    "qlo50_map", "qhi50_map", "glo50", "ghi50",
)
RUNTIME_PACKAGES = ("numpy", "pandas", "scipy", "scikit-learn", "joblib")


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def date_span(frame):
    if frame.empty:
        return {"start": None, "end": None, "rows": 0}
    return {
        "start": frame["date_day"].min().date().isoformat(),
        "end": frame["date_day"].max().date().isoformat(),
        "rows": int(len(frame)),
    }


def target_through(origin_end):
    return (date.fromisoformat(origin_end) + timedelta(days=30)).isoformat() if origin_end else None


def build_bundle(namespace, version, script, input_paths):
    """Only plain data and fitted library estimators enter the joblib bundle."""
    import xgboost

    if namespace["best_name"] != "RF_DailyNext30":
        raise ValueError(
            "Export supports the original FORCE_BEST_MODEL='RF_DailyNext30' only; "
            f"selected {namespace['best_name']!r}."
        )
    if version == "v9" and namespace["RUN_HYPERPARAMETER_TUNING"]:
        raise ValueError("Expected original v9 hyperparameter tuning to remain disabled")
    features = list(namespace["daily_features"])
    feature_config = {
        "feature_columns": features,
        "canonical_subbasins": namespace["CANONICAL_SUBBASINS"],
        "subbasin_area_tolerance_pct": namespace["SUBBASIN_AREA_TOLERANCE_PCT"],
    }
    if version == "v6":
        feature_config.update({
            "include_year_feature": bool(namespace["INCLUDE_YEAR_FEATURE"]),
            "year_feature_col": namespace["YEAR_FEATURE_COL"],
            "train_start_year": int(namespace["train_start_year"]),
        })
    else:
        feature_config.update({
            "rainfall_rolling_windows": namespace["RAINFALL_ROLLING_WINDOWS"],
            "high_qin30_threshold_train": float(namespace["high_qin30_threshold_train"]),
        })
    versions = {name: metadata.version(name) for name in RUNTIME_PACKAGES}
    versions["xgboost"] = xgboost.__version__
    versions["python"] = platform.python_version()
    splits = {
        "train": date_span(namespace["train_d"]),
        "validation": date_span(namespace["val_d"]),
        "test": date_span(namespace["test_d"]),
    }
    return {
        "schema_version": 1,
        "model_version": version,
        "best_model_name": namespace["best_name"],
        "feature_columns": features,
        "feature_config": feature_config,
        "imputer": namespace["imp_d"],
        "predictor": namespace["rf_d"],
        "prediction_kind": "log_regressor",
        "intervals": {key: namespace[key] for key in INTERVAL_KEYS},
        "runtime_versions": versions,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "training": {
            "purpose": "Original benchmark evaluation; production_training describes the deployed estimator",
            "train_start": namespace.get("TRAIN_START"),
            "train_end": int(namespace["TRAIN_END"]),
            "val_end": int(namespace["VAL_END"]),
            "validation_mode": namespace.get("VALIDATION_MODE", "chronological"),
            "splits": splits,
            "maximum_observed_date": namespace["daily"]["date_day"].max().date().isoformat(),
            "training_target_through": target_through(splits["train"]["end"]),
            "interval_calibration_origin_end": splits["validation"]["end"],
            "interval_calibration_through": target_through(splits["validation"]["end"]),
            "training_script_sha256": sha256_file(script),
            "inputs": {
                name: {"file_name": path.name, "sha256": sha256_file(path)}
                for name, path in input_paths.items()
            },
        },
    }


def refit_production_model(bundle, namespace):
    """Fit fresh estimator/imputer instances using every eligible labeled row."""
    import numpy as np
    from sklearn.base import clone

    frame = namespace["daily_model_df"].copy()
    if bundle["model_version"] == "v9":
        frame = frame.loc[frame["year"] >= namespace["TRAIN_START"]].copy()
    features = bundle["feature_columns"]
    required = ["date_day", *features, "inflow_next30", "inflow_next30_log"]
    frame = frame.dropna(subset=required).sort_values("date_day").reset_index(drop=True)
    if frame.empty:
        raise ValueError("No fully labeled rows are available for production training")

    # This optional feature is disabled in the supplied v9. If enabled later,
    # learn its threshold from production rows and recompute history consistently.
    if bundle["model_version"] == "v9" and "high_qin30_rate_365d" in features:
        history = namespace["daily"].copy().sort_values("date_day")
        production_dates = frame["date_day"]
        qin30_train = history.loc[history["date_day"].isin(production_dates), "qin_30d"].dropna()
        threshold = float(np.quantile(qin30_train, namespace["HIGH_QIN30_QUANTILE"]))
        history["high_qin30_rate_365d"] = (
            (history["qin_30d"] >= threshold).astype(float).rolling(365, min_periods=30).mean()
        )
        frame["high_qin30_rate_365d"] = frame["date_day"].map(
            history.set_index("date_day")["high_qin30_rate_365d"]
        )
        bundle["feature_config"]["high_qin30_threshold_train"] = threshold

    predictor = clone(namespace["rf_d"])
    imputer = clone(namespace["imp_d"])
    transformed = imputer.fit_transform(frame[features])
    predictor.fit(transformed, frame["inflow_next30_log"])
    bundle["predictor"] = predictor
    bundle["imputer"] = imputer
    daily = namespace["daily"].sort_values("date_day")
    recent = daily.tail(30)
    bundle["production_training"] = {
        **date_span(frame),
        "target_through": target_through(frame["date_day"].max().date().isoformat()),
        "maximum_observed_date": daily["date_day"].max().date().isoformat(),
        "excluded_recent_unlabeled_rows": int(recent["inflow_next30"].isna().sum()),
        "mode": "all_current_labeled_data",
        "train_start_constraint": namespace.get("TRAIN_START"),
        "eligibility": "All retained rows with complete selected features and observed next-30-day targets",
        "unlabeled_explanation": "The most recent 30 rows lack a complete observed future 30-day target",
        "hyperparameters": "Cloned unchanged from the selected benchmark RF",
        "optional_high_qin30_threshold_refit": "high_qin30_rate_365d" in features,
    }
    bundle["interval_calibration"] = {
        "source": "Original fixed-split benchmark model validation residuals, before production refit",
        "approximate_for_production": True,
        "note": (
            "Residual intervals are transferred from the pre-refit benchmark model. "
            "Their coverage has not been recalibrated or evaluated for the production model."
        ),
    }
    print(
        f"Production refit used {len(frame)} labeled rows, "
        f"{bundle['production_training']['start']} through {bundle['production_training']['end']}."
    )
    return frame


def verify_serialization(bundle, production_frame, path):
    """Check serialization preserves the deployed estimator's predictions."""
    import joblib
    import numpy as np

    loaded = joblib.load(path)
    features = production_frame[bundle["feature_columns"]]
    transformed = loaded["imputer"].transform(features)
    actual = np.expm1(loaded["predictor"].predict(transformed))
    expected = np.expm1(bundle["predictor"].predict(bundle["imputer"].transform(features)))
    np.testing.assert_allclose(actual, expected, rtol=1e-12, atol=1e-9)
    return {"rows": int(len(actual)), "prediction_parity": True}


def verify_features(bundle, namespace, input_paths):
    """Require inference preprocessing to match every retained training/test row."""
    import numpy as np

    sys.path.insert(0, str(PACKAGE_DIR))
    from models.feature_engineering import build_features

    expected = namespace["daily_model_df"].set_index("date_day")[bundle["feature_columns"]]
    computed = build_features(
        input_paths["data"], input_paths["rain"], input_paths["soil"],
        bundle["model_version"], as_of=expected.index.max(),
        feature_config=bundle["feature_config"],
    ).set_index("date_day")
    actual = computed.loc[expected.index, bundle["feature_columns"]]
    np.testing.assert_allclose(
        actual.to_numpy(dtype=float), expected.to_numpy(dtype=float),
        rtol=1e-10, atol=1e-8, equal_nan=True,
        err_msg="Prediction feature engineering differs from the original training script",
    )
    return {"feature_rows": int(len(expected)), "feature_parity": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", choices=("v6", "v9"), required=True)
    parser.add_argument("--data", type=Path, required=True, help="ALTU_ALL.csv")
    parser.add_argument("--rain", type=Path, required=True, help="Daily subbasin rainfall CSV")
    parser.add_argument("--soil", type=Path, required=True, help="Daily subbasin soil moisture CSV")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    input_paths = {name: getattr(args, name).resolve() for name in ("data", "rain", "soil")}
    for name, path in input_paths.items():
        if not path.is_file():
            parser.error(f"{name} input does not exist: {path}")
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    reports = output_dir / "reports"
    reports.mkdir(exist_ok=True)
    cache = output_dir / ".matplotlib"
    cache.mkdir(exist_ok=True)
    os.environ.update({
        "ALTUS_DATA_PATH": str(input_paths["data"]),
        "ALTUS_SUBBASIN_RAIN_PATH": str(input_paths["rain"]),
        "ALTUS_SUBBASIN_SM_PATH": str(input_paths["soil"]),
        "ALTUS_OUT_DIR": str(reports),
        "MPLCONFIGDIR": str(cache),
        "MPLBACKEND": "Agg",
        "OPENBLAS_NUM_THREADS": "1",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
    })
    # Import dependencies after setting thread/cache environment variables.
    import joblib
    import pandas as pd
    if str(PACKAGE_DIR) not in sys.path:
        sys.path.insert(0, str(PACKAGE_DIR))
    from ingestion.usace_daily import normalize_inflow
    history = normalize_inflow(pd.read_csv(input_paths["data"]))
    if history.empty or history.date_day.duplicated().any() or not history.date_day.diff().dropna().eq(pd.Timedelta(days=1)).all():
        raise ValueError("Inflow history must contain consecutive daily observations before training")

    script = PACKAGE_DIR / "models" / f"model_{args.version}.py"
    namespace = runpy.run_path(str(script), run_name="__altus_training__")
    bundle = build_bundle(namespace, args.version, script, input_paths)
    feature_verification = verify_features(bundle, namespace, input_paths)
    production_frame = refit_production_model(bundle, namespace)
    target = output_dir / "model.joblib"
    temporary = output_dir / "model.joblib.tmp"
    joblib.dump(bundle, temporary, compress=3)
    serialization = verify_serialization(bundle, production_frame, temporary)
    temporary.replace(target)
    public_metadata = {
        key: value for key, value in bundle.items() if key not in ("predictor", "imputer")
    }
    public_metadata["artifact_sha256"] = sha256_file(target)
    public_metadata["verification"] = {**serialization, **feature_verification}
    (output_dir / "metadata.json").write_text(
        json.dumps(public_metadata, indent=2, allow_nan=False) + "\n", encoding="utf-8",
    )
    print(f"Exported {args.version} {bundle['best_model_name']}: {target}")
    print(f"Verified {serialization['rows']} production predictions after reload.")


if __name__ == "__main__":
    main()
