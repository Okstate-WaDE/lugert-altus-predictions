"""Fetch the original GEE polygon averages without inventing unavailable days.

Source: ECMWF/ERA5_LAND/DAILY_AGGR. Rain uses total_precipitation_sum
(meters converted to millimeters); soil uses volumetric_soil_water_layer_1.
The polygon reducer and scale match altus_model_v7_package/gee_ingest.py.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
import json
from typing import Any

import pandas as pd

from ingestion.merge import normalize_subbasin_history
from models.feature_engineering import CANONICAL_SUBBASINS


DEFAULT_CONFIG = {
    "project_id": "lugert-altus",
    "subbasin_fc_asset": "projects/lugert-altus/assets/splitshed",
    "era5_daily_asset": "ECMWF/ERA5_LAND/DAILY_AGGR",
    "precip_band": "total_precipitation_sum",
    "soil_moisture_band": "volumetric_soil_water_layer_1",
    "scale_m": 10000,
    "pull_lookback_days": 120,
    "chunk_days": 31,
}


def _date(value: Any) -> date:
    parsed = pd.Timestamp(value)
    if pd.isna(parsed) or parsed.tzinfo is not None or parsed != parsed.normalize():
        raise ValueError("Dates must be whole calendar days without timezones")
    return parsed.date()


def choose_pull_start(end_date: Any, latest_stored_date: Any = None, lookback_days: int = 120) -> date:
    """Refresh at least 60 days, resuming before the saved endpoint after any gap."""
    end = _date(end_date)
    recent_start = end - timedelta(days=max(60, int(lookback_days)) - 1)
    if latest_stored_date is None:
        return recent_start
    # Refresh the latest month as well as filling all intervening missing days.
    return min(recent_start, _date(latest_stored_date) - timedelta(days=30))


def _initialize(config: dict[str, Any], credentials_json: dict[str, Any] | None):
    import ee

    project = config["project_id"]
    if not project:
        raise ValueError("GEE project_id must be configured")
    if credentials_json is not None:
        if not isinstance(credentials_json, dict) or not credentials_json.get("client_email"):
            raise ValueError("GEE service account secret must contain a JSON object with client_email")
        # Keep the key in memory. Never write it to the image, S3 history, or logs.
        credentials = ee.ServiceAccountCredentials(
            credentials_json["client_email"], key_data=json.dumps(credentials_json)
        )
        ee.Initialize(credentials=credentials, project=project)
    else:
        # Supports already configured Application Default Credentials locally.
        ee.Initialize(project=project)
    return ee


def _subbasins(ee, asset: str):
    def with_metadata(feature):
        feature = ee.Feature(feature)
        centroid = feature.geometry().centroid(1).coordinates()
        return feature.set({
            "source_feature_index": feature.id(),
            "centroid_lon": centroid.get(0),
            "centroid_lat": centroid.get(1),
            "area_m2_used": feature.geometry().area(1),
        })
    return ee.FeatureCollection(asset).map(with_metadata)


def _collection_range(collection) -> tuple[date | None, date | None]:
    low = collection.aggregate_min("system:time_start").getInfo()
    high = collection.aggregate_max("system:time_start").getInfo()
    convert = lambda value: pd.Timestamp(value, unit="ms", tz="UTC").date() if value is not None else None
    return convert(low), convert(high)


def _pull_band(ee, collection, subbasins, start: date, end: date, band: str,
               value_col: str, scale: int, multiplier: float) -> pd.DataFrame:
    images = collection.filterDate(start.isoformat(), (end + timedelta(days=1)).isoformat())
    images = images.select([band]).sort("system:time_start")
    if multiplier != 1:
        images = images.map(lambda image: ee.Image(image).multiply(multiplier).copyProperties(
            image, ["system:time_start"]
        ))

    def reduce_day(image, accumulator):
        image = ee.Image(image)
        day = ee.Date(image.get("system:time_start")).format("YYYY-MM-dd")
        # Use entire existing watershed polygons at the original scale. The
        # centroid above is audit metadata and is never used to sample values.
        reduced = image.reduceRegions(collection=subbasins, reducer=ee.Reducer.mean(), scale=scale)
        reduced = reduced.map(lambda feature: ee.Feature(feature).set({
            "date": day, "value": ee.Feature(feature).get("mean")
        }).setGeometry(None))
        return ee.FeatureCollection(accumulator).merge(reduced)

    payload = ee.FeatureCollection(images.iterate(reduce_day, ee.FeatureCollection([]))).getInfo()
    rows = []
    for feature in payload.get("features", []):
        props = feature.get("properties", {})
        # Missing pixels/days remain missing. In particular, no zero is created
        # just because an image or a polygon reduction is not yet available.
        if props.get("value") is None:
            continue
        rows.append({
            "date": props.get("date"),
            "subbasin_id": props.get("subbasin_id"),
            "source_feature_index": props.get("source_feature_index"),
            "centroid_lon": props.get("centroid_lon"),
            "centroid_lat": props.get("centroid_lat"),
            "area_m2_used": props.get("area_m2_used"),
            value_col: props.get("value"),
        })
    return normalize_subbasin_history(pd.DataFrame(rows), value_col)


def _complete_dates(frame: pd.DataFrame, value_col: str) -> set[str]:
    if frame.empty:
        return set()
    canonical = {basin["subbasin_id"] for basin in CANONICAL_SUBBASINS}
    valid = frame.loc[frame[value_col].notna()]
    return {day for day, group in valid.groupby("date") if set(group["subbasin_id"]) == canonical}


def fetch_subbasin_daily(
    start_date: Any, end_date: Any, config: dict[str, Any],
    credentials_json: dict[str, Any] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Return rainfall, soil moisture, and live availability/provenance metadata.

    Both dates are inclusive. ``config`` is the ``gee`` object from the daily
    configuration. The optional secret is the service-account JSON loaded by
    the runner from Secrets Manager; it is used only for in-memory credentials.
    """
    started = datetime.now(timezone.utc)
    start, end = _date(start_date), _date(end_date)
    if start > end:
        raise ValueError("start_date cannot be after end_date")
    settings = {**DEFAULT_CONFIG, **config}
    for key in ("subbasin_fc_asset", "era5_daily_asset", "precip_band", "soil_moisture_band"):
        if not settings[key]:
            raise ValueError(f"Missing GEE {key}")
    scale, chunk_days = int(settings["scale_m"]), int(settings["chunk_days"])
    if scale <= 0 or not 1 <= chunk_days <= 90:
        raise ValueError("GEE scale_m must be positive and chunk_days must be between 1 and 90")
    ee = _initialize(settings, credentials_json)
    collection = ee.ImageCollection(settings["era5_daily_asset"])
    available_start, available_end = _collection_range(collection)
    rain_parts, soil_parts = [], []
    if available_start is not None and available_end is not None:
        query_start, query_end = max(start, available_start), min(end, available_end)
        if query_start <= query_end:
            basins = _subbasins(ee, settings["subbasin_fc_asset"])
            cursor = query_start
            while cursor <= query_end:
                stop = min(query_end, cursor + timedelta(days=chunk_days - 1))
                rain_parts.append(_pull_band(ee, collection, basins, cursor, stop,
                                             settings["precip_band"], "rain_mm_aw", scale, 1000.0))
                soil_parts.append(_pull_band(ee, collection, basins, cursor, stop,
                                             settings["soil_moisture_band"], "sm_aw", scale, 1.0))
                cursor = stop + timedelta(days=1)
    rain = normalize_subbasin_history(pd.concat(rain_parts, ignore_index=True) if rain_parts else pd.DataFrame(), "rain_mm_aw")
    soil = normalize_subbasin_history(pd.concat(soil_parts, ignore_index=True) if soil_parts else pd.DataFrame(), "sm_aw")
    complete = _complete_dates(rain, "rain_mm_aw") & _complete_dates(soil, "sm_aw")
    requested_dates = {stamp.strftime("%Y-%m-%d") for stamp in pd.date_range(start, end, freq="D")}
    actual_end = max(complete) if complete else None
    metadata = {
        "source": "Google Earth Engine ERA5-Land daily aggregates",
        "started_at_utc": started.isoformat(),
        "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        "project_id": settings["project_id"],
        "subbasin_fc_asset": settings["subbasin_fc_asset"],
        "era5_daily_asset": settings["era5_daily_asset"],
        "precip_band": settings["precip_band"], "soil_moisture_band": settings["soil_moisture_band"],
        "scale_m": scale, "reducer": "mean over original subbasin polygons",
        "rain_units": "mm/day", "soil_units": "volume fraction (m3/m3), layer 1 (0-7 cm)",
        "requested_start_date": start.isoformat(), "requested_end_date": end.isoformat(),
        "collection_available_start_date": available_start.isoformat() if available_start else None,
        "collection_available_end_date": available_end.isoformat() if available_end else None,
        "actual_start_date": min(complete) if complete else None, "actual_end_date": actual_end,
        "requested_day_available": end.isoformat() in complete,
        "lag_days": max(0, (end - _date(actual_end)).days) if actual_end else None,
        "collection_lag_days": max(0, (end - available_end).days) if available_end else None,
        "pending_dates": sorted(requested_dates - complete),
        "rain_rows_pulled": len(rain), "soil_rows_pulled": len(soil),
    }
    return rain, soil, metadata
