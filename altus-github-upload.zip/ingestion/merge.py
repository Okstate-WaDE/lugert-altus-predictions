"""Canonical, correction-safe updates of the rainfall and soil-moisture histories."""

from __future__ import annotations

import numpy as np
import pandas as pd

from models.feature_engineering import CANONICAL_SUBBASINS


def normalize_subbasin_history(frame: pd.DataFrame, value_col: str) -> pd.DataFrame:
    """Resolve legacy areas to the same four basins used by v6/v9 training."""
    required = ["date", "area_m2_used", value_col]
    if frame.empty:
        return pd.DataFrame(columns=["date", "subbasin_id", "area_m2_used", value_col])
    missing = set(required).difference(frame.columns)
    if missing:
        raise ValueError(f"Subbasin history is missing columns: {sorted(missing)}")
    out = frame.copy()
    dates = pd.to_datetime(out["date"], errors="coerce", format="mixed")
    if dates.isna().any() or not pd.api.types.is_datetime64_dtype(dates.dtype):
        raise ValueError("Subbasin history contains invalid dates or timezones")
    if not dates.eq(dates.dt.normalize()).all():
        raise ValueError("Subbasin history dates must identify whole calendar days")
    out["date"] = dates.dt.strftime("%Y-%m-%d")
    areas = pd.to_numeric(out["area_m2_used"], errors="coerce")
    if areas.isna().any() or (~np.isfinite(areas)).any() or (areas <= 0).any():
        raise ValueError("Subbasin history contains invalid basin areas")
    canonical = pd.DataFrame(CANONICAL_SUBBASINS)
    mappings, area_mappings = {}, {}
    for area in areas.unique():
        basin = canonical.loc[(canonical["representative_area_m2"] - area).abs().idxmin()]
        difference = abs(basin["representative_area_m2"] - area) / area * 100.0
        if difference > 2.0:
            raise ValueError(f"Subbasin area {area} is outside the 2% canonical area tolerance")
        mappings[area] = basin["subbasin_id"]
        area_mappings[area] = basin["representative_area_m2"]
    if "source_area_m2" not in out:
        out["source_area_m2"] = areas
    out["area_m2_used"] = areas.map(area_mappings)
    out["subbasin_id"] = areas.map(mappings)
    values = pd.to_numeric(out[value_col], errors="coerce")
    if (~np.isfinite(values.dropna())).any():
        raise ValueError(f"Subbasin history contains infinite {value_col} values")
    out[value_col] = values
    # Original training averages duplicate date/basin observations. Preserve
    # that behavior within each batch; a newer batch supersedes the old value.
    aggregations = {column: "last" for column in out.columns if column not in {"date", "subbasin_id"}}
    aggregations[value_col] = "mean"
    return out.groupby(["date", "subbasin_id"], as_index=False).agg(aggregations)


def merge_subbasin_history(previous: pd.DataFrame, incoming: pd.DataFrame, value_col: str) -> pd.DataFrame:
    """Upsert by date/canonical basin; unavailable incoming values never erase data."""
    old = normalize_subbasin_history(previous, value_col)
    new = normalize_subbasin_history(incoming, value_col)
    new = new.loc[new[value_col].notna()].copy()
    if new.empty:
        return old.sort_values(["date", "subbasin_id"]).reset_index(drop=True)
    if old.empty:
        return new.sort_values(["date", "subbasin_id"]).reset_index(drop=True)
    merged = new.set_index(["date", "subbasin_id"]).combine_first(old.set_index(["date", "subbasin_id"]))
    return merged.reset_index().sort_values(["date", "subbasin_id"]).reset_index(drop=True)
