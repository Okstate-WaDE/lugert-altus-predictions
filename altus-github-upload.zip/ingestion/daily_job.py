"""Scheduled CodeBuild job: collect, backfill, train both versions, publish atomically."""

from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import uuid
from zoneinfo import ZoneInfo

PACKAGE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_DIR))

import pandas as pd
from inference import load_bundle, predict
from ingestion.availability import latest_common_date
from ingestion.gee_daily import choose_pull_start, fetch_subbasin_daily
from ingestion.merge import merge_subbasin_history
from ingestion.usace_daily import collect_inflow, merge_inflow, normalize_inflow
from lambda_function import INPUT_FILES


def read_json(s3, bucket, key, default=None):
    try:
        return json.loads(s3.get_object(Bucket=bucket, Key=key)['Body'].read())
    except Exception as error:
        code = getattr(error, 'response', {}).get('Error', {}).get('Code')
        if default is not None and code in ('NoSuchKey', '404'):
            return default
        raise


def put_json(s3, bucket, key, value):
    s3.put_object(Bucket=bucket, Key=key, ContentType='application/json',
                  Body=json.dumps(value, indent=2, allow_nan=False).encode())


def run(s3, secrets, bucket, config_key, secret_arn, workdir):
    config = read_json(s3, bucket, config_key)
    end = datetime.now(ZoneInfo(config.get('timezone', 'America/Chicago'))).date() - timedelta(days=1)
    manifest = read_json(s3, bucket, 'inputs/current.json', {'input_prefix': 'inputs/'})
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    input_dir = workdir / 'data'
    input_dir.mkdir()
    paths = [input_dir / name for name in INPUT_FILES]
    for path in paths:
        s3.download_file(bucket, manifest['input_prefix'] + path.name, str(path))
    old_inflow, old_rain, old_soil = [pd.read_csv(path) for path in paths]
    latest_inflow = normalize_inflow(old_inflow).date_day.max().date()
    old_rain_end = pd.to_datetime(old_rain.date).max().date()
    old_soil_end = pd.to_datetime(old_soil.date).max().date()
    lookback = int(config.get('lookback_days', 120))
    start = choose_pull_start(end, min(old_rain_end, old_soil_end), lookback)
    credential_data = json.loads(secrets.get_secret_value(SecretId=secret_arn)['SecretString'])
    rain, soil, weather_status = fetch_subbasin_daily(start, end, config.get('gee', {}), credential_data)
    del credential_data
    inflow_start = choose_pull_start(end, latest_inflow, lookback)
    new_inflow, inflow_status = collect_inflow(inflow_start, end, config.get('usace', {}))
    inflow = merge_inflow(old_inflow, new_inflow)
    rain = merge_subbasin_history(old_rain, rain, 'rain_mm_aw')
    soil = merge_subbasin_history(old_soil, soil, 'sm_aw')
    inflow = inflow.loc[inflow.date_day <= pd.Timestamp(end)]
    if inflow.date_day.duplicated().any() or not inflow.date_day.diff().dropna().eq(pd.Timedelta(days=1)).all():
        raise ValueError('Inflow history has missing or duplicate dates; backfill before training')
    rain = rain.loc[pd.to_datetime(rain.date) <= pd.Timestamp(end)]
    soil = soil.loc[pd.to_datetime(soil.date) <= pd.Timestamp(end)]
    common_date = latest_common_date(inflow, rain, soil)
    inflow.drop(columns=['date_day']).to_csv(paths[0], index=False)
    rain.to_csv(paths[1], index=False)
    soil.to_csv(paths[2], index=False)
    hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    status = {'run_id': run_id, 'requested_date': end.isoformat(), 'as_of': common_date.isoformat(),
              'lag_days': (end - common_date).days, 'weather': weather_status, 'inflow': inflow_status,
              'input_sha256': hashes}
    if hashes == manifest.get('input_sha256'):
        status['status'] = 'unchanged'
        put_json(s3, bucket, f'status/{run_id}.json', status)
        put_json(s3, bucket, 'status/latest.json', status)
        return status

    models, predictions = {}, {}
    # Both versions must pass training, feature parity and a real prediction before promotion.
    for model_version in ('v6', 'v9'):
        artifact_dir = workdir / model_version
        subprocess.run([sys.executable, str(PACKAGE_DIR / 'tools/export_model.py'),
                        '--version', model_version, '--data', str(paths[0]), '--rain', str(paths[1]),
                        '--soil', str(paths[2]), '--output-dir', str(artifact_dir)], check=True, timeout=6600)
        bundle = load_bundle(artifact_dir / 'model.joblib', model_version)
        predictions[model_version] = predict(bundle, *paths, as_of=common_date.isoformat())
        model_key = f'models/{model_version}/runs/{run_id}/model.joblib'
        models[model_version] = model_key
        s3.upload_file(str(artifact_dir / 'model.joblib'), bucket, model_key)
        s3.upload_file(str(artifact_dir / 'metadata.json'), bucket,
                       f'models/{model_version}/runs/{run_id}/metadata.json')
        put_json(s3, bucket, f'outputs/{model_version}/{run_id}/prediction.json', predictions[model_version])
    input_prefix = f'inputs/runs/{run_id}/'
    for path in paths:
        s3.upload_file(str(path), bucket, input_prefix + path.name)
    status.update(status='published', model_keys=models, input_prefix=input_prefix)
    put_json(s3, bucket, f'status/{run_id}.json', status)
    # Single pointer changes only after ALL immutable inputs and models are ready.
    put_json(s3, bucket, 'inputs/current.json', status)
    put_json(s3, bucket, 'status/latest.json', status)
    return status


def main():
    import boto3
    from botocore.config import Config
    settings = Config(connect_timeout=10, read_timeout=120, retries={'max_attempts': 3, 'mode': 'standard'})
    s3 = boto3.client('s3', config=settings)
    secrets = boto3.client('secretsmanager', config=settings)
    bucket = os.environ['DATA_BUCKET']
    try:
        with tempfile.TemporaryDirectory(prefix='altus-daily-') as work:
            result = run(s3, secrets, bucket, os.environ.get('CONFIG_KEY', 'config/daily.json'),
                         os.environ['EARTH_ENGINE_SECRET_ARN'], Path(work))
        print(json.dumps(result, allow_nan=False))
    except Exception as error:
        put_json(s3, bucket, 'status/latest.json', {'status': 'failed', 'error_type': type(error).__name__,
                 'at': datetime.now(timezone.utc).isoformat(), 'note': 'Previous published manifest retained'})
        raise


if __name__ == '__main__':
    main()
