"""Read the same USACE monthly ALTU reports used to create ALTU_ALL.csv."""

from datetime import date
import re
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pandas as pd

MONTHS = 'JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC'.split()
COLUMNS = ['day', 'pool', 'elevations (ft)', 'storage (2400hr)',
           'releases (power)', 'releases (total)', 'evap inches', 'inflow adj',
           'rainfall inches (7A to Dam)', 'rainfall inches (7A to BSN)']
URL = 'https://www.swt-wc.usace.army.mil/charts/bins/ALTU{month}{year2}.txt'


def normalize_inflow(frame):
    out = frame.loc[:, ~frame.columns.str.startswith('Unnamed:')].copy()
    month = out['month'].astype(str).str.upper().str.strip().replace(
        {name: str(i + 1) for i, name in enumerate(MONTHS)})
    out['month'] = pd.to_numeric(month, errors='raise').astype(int)
    out['year'] = pd.to_numeric(out['year'], errors='raise').astype(int)
    out['day'] = pd.to_numeric(out['day'], errors='raise').astype(int)
    out['date_day'] = pd.to_datetime(out[['year', 'month', 'day']], errors='raise')
    out['inflow adj'] = pd.to_numeric(out['inflow adj'], errors='coerce')
    return out.dropna(subset=['inflow adj']).sort_values('date_day').reset_index(drop=True)


def parse_report(text, year, month):
    if 'MONTHLY LAKE REPORT' not in text or 'ALTUS' not in text.upper():
        raise ValueError('USACE response is not an Altus monthly lake report')
    if not re.search(rf'\b{MONTHS[month - 1]}\s+{year}\b', text):
        raise ValueError('USACE report date does not match the requested month')
    rows = []
    for line in text.splitlines():
        parts = line.split()
        if not parts or not re.fullmatch(r'\d{1,2}', parts[0]):
            continue
        day = int(parts[0])
        if not 1 <= day <= 31:
            continue
        if len(parts) < len(COLUMNS):
            # A report may contain a current day with no observations yet.
            if len(parts) == 1:
                continue
            raise ValueError(f'USACE daily row has changed format: {line}')
        date(year, month, day)
        values = pd.to_numeric(pd.Series(parts[:len(COLUMNS)]), errors='coerce')
        row = dict(zip(COLUMNS, values.tolist()))
        if pd.isna(row['inflow adj']):
            continue
        row.update(year=year, month=month)
        rows.append(row)
    return pd.DataFrame(rows, columns=COLUMNS + ['month', 'year'])


def collect_inflow(start_date, end_date, config=None):
    config = config or {}
    current = start_date.replace(day=1)
    frames, sources, pending = [], [], []
    while current <= end_date:
        url = config.get('report_url_template', URL).format(
            month=MONTHS[current.month - 1], year=current.year, year2=f'{current.year % 100:02d}')
        request = Request(url, headers={
            'User-Agent': 'AltusModelDailyUpdater/1.0',
            'Referer': 'https://www.swt-wc.usace.army.mil/charts/?monthly=&proj=ALTU',
        })
        try:
            with urlopen(request, timeout=60) as response:
                text = response.read().decode('utf-8-sig')
        except HTTPError as error:
            if error.code == 404:
                pending.append(current.isoformat())
                current = date(current.year + (current.month == 12), current.month % 12 + 1, 1)
                continue
            raise
        # The report server also serves its missing-report page with HTTP 200.
        if re.search(r'<title>\s*404\s*:\s*Not Found\s*</title>', text, re.IGNORECASE):
            pending.append(current.isoformat())
            current = date(current.year + (current.month == 12), current.month % 12 + 1, 1)
            continue
        frames.append(parse_report(text, current.year, current.month))
        sources.append(url)
        current = date(current.year + (current.month == 12), current.month % 12 + 1, 1)
    frame = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=COLUMNS + ['month', 'year'])
    if not frame.empty:
        frame = normalize_inflow(frame)
        frame = frame.loc[frame.date_day.between(pd.Timestamp(start_date), pd.Timestamp(end_date))]
    return frame, {'sources': sources, 'unpublished_months': pending}


def merge_inflow(previous, incoming):
    old = normalize_inflow(previous).set_index('date_day')
    if old.index.has_duplicates:
        raise ValueError('Existing inflow history contains duplicate days')
    if incoming.empty:
        return old.reset_index()
    new = normalize_inflow(incoming).set_index('date_day')
    if new.index.has_duplicates:
        raise ValueError('New inflow reports contain duplicate days')
    return new.combine_first(old).sort_index().reset_index()
