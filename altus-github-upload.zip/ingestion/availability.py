"""Find an observed forecast date shared by inflow and all four weather basins."""

import pandas as pd


def complete_dates(frame, value_col):
    counts = frame.loc[frame[value_col].notna()].groupby('date').subbasin_id.nunique()
    return {pd.Timestamp(day).date() for day in counts[counts == 4].index}


def latest_common_date(inflow, rain, soil):
    shared = (set(inflow.date_day.dt.date) & complete_dates(rain, 'rain_mm_aw')
              & complete_dates(soil, 'sm_aw'))
    if not shared:
        raise ValueError('No dates with complete inflow and four-basin weather')
    return max(shared)
